/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        // --- Nutrition Assistant brand palette ---
        forest: {
          DEFAULT: "#163A2E", // deep forest green — headings, dark sections
          light: "#1F4E3D",
        },
        brand: {
          DEFAULT: "#2F6F4E", // core brand green — buttons, links
          dark: "#255A3F",
          light: "#3E8A63",
        },
        fresh: {
          DEFAULT: "#6FCF97", // bright accent green — highlights, active states
          light: "#9EE6BB",
        },
        mist: "#EAF6EF", // very light green-white — section backgrounds
        paper: "#FFFFFF", // pure white
        ink: "#142420", // near-black green — body text
        muted: "#5B7768", // secondary/muted text
      },
      fontFamily: {
        display: ["Fraunces", "serif"],
        body: ["Inter", "sans-serif"],
      },
      borderRadius: {
        xl2: "1.25rem",
      },
      boxShadow: {
        soft: "0 8px 30px -12px rgba(22, 58, 46, 0.25)",
      },
      backgroundImage: {
        "ring-fade": "radial-gradient(circle at center, rgba(111,207,151,0.18) 0%, rgba(111,207,151,0) 70%)",
      },
    },
  },
  plugins: [],
};
