export const isValidEmail = (value) =>
  /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/.test(value);

export const isValidPassword = (value) => typeof value === "string" && value.length >= 6;
