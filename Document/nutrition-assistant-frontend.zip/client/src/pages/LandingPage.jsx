import React from "react";
import { Link } from "react-router-dom";
import { HiOutlineArrowRight } from "react-icons/hi";
import MacroRing from "../components/ui/MacroRing.jsx";

const nutrients = [
  {
    label: "Protein",
    detail: "Track grams consumed against a target built from your goal and activity level.",
    swatch: "bg-forest",
  },
  {
    label: "Carbohydrates",
    detail: "See where your energy is coming from across the day, meal by meal.",
    swatch: "bg-brand",
  },
  {
    label: "Fats",
    detail: "Keep essential fats in range without needing to do the math yourself.",
    swatch: "bg-fresh",
  },
];

const steps = [
  {
    title: "Tell us about you",
    detail: "Age, height, weight, activity level, and your goal — takes under a minute.",
  },
  {
    title: "Get your daily targets",
    detail: "We calculate calorie and macro targets tailored to what you're trying to achieve.",
  },
  {
    title: "Log meals as you go",
    detail: "Search the food database, log what you ate, and watch your progress fill in.",
  },
];

const LandingPage = () => {
  return (
    <>
      {/* ---------------- Hero ---------------- */}
      <section className="relative overflow-hidden bg-mist">
        <div className="mx-auto grid max-w-7xl grid-cols-1 items-center gap-12 px-6 py-16 sm:py-20 lg:grid-cols-2 lg:px-8 lg:py-28">
          <div>
            <p className="eyebrow">Daily nutrition, made legible</p>
            <h1 className="mt-4 font-display text-4xl font-semibold leading-[1.1] text-forest sm:text-5xl lg:text-6xl">
              Know exactly what's on
              <br />
              <span className="italic text-brand">your plate.</span>
            </h1>
            <p className="mt-6 max-w-lg font-body text-base leading-relaxed text-muted sm:text-lg">
              Nutrition Assistant turns your meals into clear, daily numbers —
              calories, protein, carbs, and fats — so you always know how
              close you are to your goal.
            </p>

            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <Link to="/register" className="btn-primary">
                Create your free account
                <HiOutlineArrowRight />
              </Link>
              <Link to="/login" className="btn-secondary">
                I already have an account
              </Link>
            </div>

            <div className="mt-10 flex items-center gap-8">
              <div>
                <p className="font-display text-2xl font-semibold text-forest">3</p>
                <p className="font-body text-xs text-muted">core macros tracked</p>
              </div>
              <div className="h-8 w-px bg-forest/10" />
              <div>
                <p className="font-display text-2xl font-semibold text-forest">1 min</p>
                <p className="font-body text-xs text-muted">to set up your profile</p>
              </div>
              <div className="h-8 w-px bg-forest/10" />
              <div>
                <p className="font-display text-2xl font-semibold text-forest">Free</p>
                <p className="font-body text-xs text-muted">for every student</p>
              </div>
            </div>
          </div>

          {/* Signature macro-ring visual with floating stat cards */}
          <div className="relative mx-auto w-full max-w-md lg:max-w-lg">
            <MacroRing className="w-full" />

            <div className="absolute -left-4 top-6 rounded-2xl bg-white px-4 py-3 shadow-soft sm:-left-8">
              <p className="font-body text-[11px] font-semibold uppercase tracking-wide text-muted">
                Protein
              </p>
              <p className="font-display text-lg font-semibold text-forest">86g / 120g</p>
            </div>

            <div className="absolute -right-2 top-1/3 rounded-2xl bg-white px-4 py-3 shadow-soft sm:-right-6">
              <p className="font-body text-[11px] font-semibold uppercase tracking-wide text-muted">
                Calories
              </p>
              <p className="font-display text-lg font-semibold text-forest">1,540 kcal</p>
            </div>

            <div className="absolute -bottom-4 left-1/4 rounded-2xl bg-white px-4 py-3 shadow-soft">
              <p className="font-body text-[11px] font-semibold uppercase tracking-wide text-muted">
                Water
              </p>
              <p className="font-display text-lg font-semibold text-forest">5 / 8 cups</p>
            </div>
          </div>
        </div>
      </section>

      {/* ---------------- Nutrients strip ---------------- */}
      <section id="nutrients" className="mx-auto max-w-7xl px-6 py-20 lg:px-8">
        <div className="max-w-2xl">
          <p className="eyebrow">What we track</p>
          <h2 className="mt-3 font-display text-3xl font-semibold text-forest sm:text-4xl">
            The three numbers that actually move the needle
          </h2>
        </div>

        <div className="mt-12 grid grid-cols-1 gap-6 sm:grid-cols-3">
          {nutrients.map((item) => (
            <div
              key={item.label}
              className="rounded-xl2 border border-forest/10 bg-white p-6 transition-shadow hover:shadow-soft"
            >
              <span className={`inline-block h-2.5 w-2.5 rounded-full ${item.swatch}`} />
              <h3 className="mt-4 font-display text-xl font-semibold text-forest">
                {item.label}
              </h3>
              <p className="mt-2 font-body text-sm leading-relaxed text-muted">
                {item.detail}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* ---------------- How it works ---------------- */}
      <section id="how-it-works" className="bg-forest">
        <div className="mx-auto max-w-7xl px-6 py-20 lg:px-8">
          <div className="max-w-2xl">
            <p className="font-body text-xs font-semibold uppercase tracking-[0.2em] text-fresh">
              How it works
            </p>
            <h2 className="mt-3 font-display text-3xl font-semibold text-white sm:text-4xl">
              From sign-up to your first logged meal
            </h2>
          </div>

          <ol className="mt-12 grid grid-cols-1 gap-8 sm:grid-cols-3">
            {steps.map((step, index) => (
              <li key={step.title} className="border-t-2 border-fresh/40 pt-5">
                <span className="font-display text-sm text-fresh">
                  Step {index + 1}
                </span>
                <h3 className="mt-2 font-display text-xl font-semibold text-white">
                  {step.title}
                </h3>
                <p className="mt-2 font-body text-sm leading-relaxed text-white/70">
                  {step.detail}
                </p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      {/* ---------------- CTA ---------------- */}
      <section id="about" className="mx-auto max-w-7xl px-6 py-20 lg:px-8">
        <div className="flex flex-col items-start justify-between gap-8 rounded-xl2 bg-mist p-10 sm:p-14 lg:flex-row lg:items-center">
          <div className="max-w-xl">
            <h2 className="font-display text-3xl font-semibold text-forest sm:text-4xl">
              Ready to see your nutrition clearly?
            </h2>
            <p className="mt-3 font-body text-base text-muted">
              Set up your profile in under a minute and get your first daily
              targets right away.
            </p>
          </div>
          <Link to="/register" className="btn-primary shrink-0">
            Get started — it's free
            <HiOutlineArrowRight />
          </Link>
        </div>
      </section>
    </>
  );
};

export default LandingPage;
