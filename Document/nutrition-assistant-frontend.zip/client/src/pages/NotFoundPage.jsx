import React from "react";
import { Link } from "react-router-dom";
import { HiOutlineArrowLeft } from "react-icons/hi";

const NotFoundPage = () => {
  return (
    <section className="mx-auto flex min-h-[calc(100vh-73px)] max-w-2xl flex-col items-center justify-center px-6 text-center">
      <p className="eyebrow">Error 404</p>
      <h1 className="mt-3 font-display text-4xl font-semibold text-forest">
        This page isn't on the menu.
      </h1>
      <p className="mt-3 font-body text-base text-muted">
        The page you're looking for doesn't exist or may have moved.
      </p>
      <Link to="/" className="btn-primary mt-8">
        <HiOutlineArrowLeft />
        Back to home
      </Link>
    </section>
  );
};

export default NotFoundPage;
