import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { HiOutlineArrowRight, HiOutlineEye, HiOutlineEyeOff } from "react-icons/hi";
import { useAuth } from "../context/AuthContext.jsx";
import { isValidEmail, isValidPassword } from "../utils/validators.js";
import MacroRing from "../components/ui/MacroRing.jsx";

const RegisterPage = () => {
  const { register, loading } = useAuth();
  const navigate = useNavigate();

  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
    confirmPassword: "",
  });
  const [errors, setErrors] = useState({});
  const [showPassword, setShowPassword] = useState(false);
  const [serverError, setServerError] = useState("");

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => ({ ...prev, [name]: "" }));
  };

  const validate = () => {
    const next = {};
    if (!form.name.trim()) next.name = "Name is required.";
    if (!isValidEmail(form.email)) next.email = "Enter a valid email address.";
    if (!isValidPassword(form.password))
      next.password = "Password must be at least 6 characters.";
    if (form.confirmPassword !== form.password)
      next.confirmPassword = "Passwords do not match.";
    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setServerError("");
    if (!validate()) return;

    try {
      await register({ name: form.name, email: form.email, password: form.password });
      navigate("/home", { replace: true });
    } catch (err) {
      setServerError(err.message || "Unable to create your account. Please try again.");
    }
  };

  return (
    <section className="mx-auto grid min-h-[calc(100vh-73px)] max-w-7xl grid-cols-1 items-center gap-12 px-6 py-16 lg:grid-cols-2 lg:px-8">
      {/* Left: visual */}
      <div className="order-2 hidden justify-center lg:order-1 lg:flex">
        <div className="relative w-full max-w-sm rounded-xl2 bg-mist p-10">
          <MacroRing className="w-full" />
        </div>
      </div>

      {/* Right: form */}
      <div className="order-1 mx-auto w-full max-w-md lg:order-2">
        <p className="eyebrow">Get started</p>
        <h1 className="mt-3 font-display text-3xl font-semibold text-forest sm:text-4xl">
          Create your account
        </h1>
        <p className="mt-3 font-body text-sm text-muted">
          Takes under a minute — you'll set daily targets right after.
        </p>

        <form onSubmit={handleSubmit} noValidate className="mt-8 space-y-5">
          {serverError && (
            <div className="rounded-xl border border-red-200 bg-red-50 px-4 py-3 font-body text-sm text-red-700">
              {serverError}
            </div>
          )}

          <div>
            <label htmlFor="name" className="mb-1.5 block font-body text-sm font-medium text-ink">
              Full name
            </label>
            <input
              id="name"
              name="name"
              type="text"
              autoComplete="name"
              placeholder="Jordan Lee"
              value={form.name}
              onChange={handleChange}
              className="input-field"
              aria-invalid={Boolean(errors.name)}
              aria-describedby={errors.name ? "name-error" : undefined}
            />
            {errors.name && (
              <p id="name-error" className="mt-1.5 font-body text-xs text-red-600">
                {errors.name}
              </p>
            )}
          </div>

          <div>
            <label htmlFor="email" className="mb-1.5 block font-body text-sm font-medium text-ink">
              Email
            </label>
            <input
              id="email"
              name="email"
              type="email"
              autoComplete="email"
              placeholder="you@example.com"
              value={form.email}
              onChange={handleChange}
              className="input-field"
              aria-invalid={Boolean(errors.email)}
              aria-describedby={errors.email ? "email-error" : undefined}
            />
            {errors.email && (
              <p id="email-error" className="mt-1.5 font-body text-xs text-red-600">
                {errors.email}
              </p>
            )}
          </div>

          <div>
            <label htmlFor="password" className="mb-1.5 block font-body text-sm font-medium text-ink">
              Password
            </label>
            <div className="relative">
              <input
                id="password"
                name="password"
                type={showPassword ? "text" : "password"}
                autoComplete="new-password"
                placeholder="At least 6 characters"
                value={form.password}
                onChange={handleChange}
                className="input-field pr-11"
                aria-invalid={Boolean(errors.password)}
                aria-describedby={errors.password ? "password-error" : undefined}
              />
              <button
                type="button"
                onClick={() => setShowPassword((prev) => !prev)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted hover:text-brand"
                aria-label={showPassword ? "Hide password" : "Show password"}
              >
                {showPassword ? <HiOutlineEyeOff size={20} /> : <HiOutlineEye size={20} />}
              </button>
            </div>
            {errors.password && (
              <p id="password-error" className="mt-1.5 font-body text-xs text-red-600">
                {errors.password}
              </p>
            )}
          </div>

          <div>
            <label htmlFor="confirmPassword" className="mb-1.5 block font-body text-sm font-medium text-ink">
              Confirm password
            </label>
            <input
              id="confirmPassword"
              name="confirmPassword"
              type={showPassword ? "text" : "password"}
              autoComplete="new-password"
              placeholder="Re-enter your password"
              value={form.confirmPassword}
              onChange={handleChange}
              className="input-field"
              aria-invalid={Boolean(errors.confirmPassword)}
              aria-describedby={errors.confirmPassword ? "confirm-error" : undefined}
            />
            {errors.confirmPassword && (
              <p id="confirm-error" className="mt-1.5 font-body text-xs text-red-600">
                {errors.confirmPassword}
              </p>
            )}
          </div>

          <button type="submit" disabled={loading} className="btn-primary w-full disabled:opacity-60">
            {loading ? "Creating account..." : "Create account"}
            {!loading && <HiOutlineArrowRight />}
          </button>
        </form>

        <p className="mt-6 text-center font-body text-sm text-muted">
          Already have an account?{" "}
          <Link to="/login" className="font-semibold text-brand hover:underline">
            Log in
          </Link>
        </p>
      </div>
    </section>
  );
};

export default RegisterPage;
