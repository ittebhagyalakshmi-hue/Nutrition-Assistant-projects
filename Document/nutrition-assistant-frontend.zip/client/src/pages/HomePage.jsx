import React from "react";
import { useAuth } from "../context/AuthContext.jsx";
import MacroRing from "../components/ui/MacroRing.jsx";

const HomePage = () => {
  const { user } = useAuth();
  const firstName = user?.name?.split(" ")[0] || "there";

  return (
    <section className="mx-auto flex max-w-4xl flex-col items-center px-6 py-20 text-center lg:px-8">
      <p className="eyebrow">Welcome back</p>
      <h1 className="mt-3 font-display text-3xl font-semibold text-forest sm:text-4xl">
        Good to see you, {firstName}.
      </h1>
      <p className="mt-4 max-w-md font-body text-base text-muted">
        Your personalized dashboard — meal logging, daily targets, and
        progress charts — is coming up next.
      </p>

      <MacroRing className="mt-10 w-full max-w-xs opacity-90" />

      <div className="mt-10 rounded-xl2 border border-forest/10 bg-mist px-6 py-4">
        <p className="font-body text-sm text-muted">
          Signed in as <span className="font-semibold text-forest">{user?.email}</span>
        </p>
      </div>
    </section>
  );
};

export default HomePage;
