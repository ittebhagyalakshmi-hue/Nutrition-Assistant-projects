import React from "react";

/**
 * MacroRing — the app's signature visual motif.
 * A set of concentric arcs inspired by a nutrition label's macro breakdown
 * (protein / carbs / fats), used in the hero and as a decorative accent
 * throughout the marketing pages.
 */
const MacroRing = ({ className = "" }) => {
  return (
    <svg
      viewBox="0 0 400 400"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      role="img"
      aria-label="Illustration of concentric rings representing balanced daily nutrition"
    >
      <circle cx="200" cy="200" r="180" fill="#EAF6EF" />

      {/* Outer track */}
      <circle cx="200" cy="200" r="150" stroke="#CFEBDA" strokeWidth="14" />

      {/* Protein arc */}
      <circle
        cx="200"
        cy="200"
        r="150"
        stroke="#163A2E"
        strokeWidth="14"
        strokeLinecap="round"
        strokeDasharray="943"
        strokeDashoffset="660"
        transform="rotate(-90 200 200)"
      />

      {/* Middle track */}
      <circle cx="200" cy="200" r="112" stroke="#CFEBDA" strokeWidth="14" />

      {/* Carbs arc */}
      <circle
        cx="200"
        cy="200"
        r="112"
        stroke="#2F6F4E"
        strokeWidth="14"
        strokeLinecap="round"
        strokeDasharray="704"
        strokeDashoffset="380"
        transform="rotate(-90 200 200)"
      />

      {/* Inner track */}
      <circle cx="200" cy="200" r="74" stroke="#CFEBDA" strokeWidth="14" />

      {/* Fats arc */}
      <circle
        cx="200"
        cy="200"
        r="74"
        stroke="#6FCF97"
        strokeWidth="14"
        strokeLinecap="round"
        strokeDasharray="465"
        strokeDashoffset="300"
        transform="rotate(-90 200 200)"
      />

      {/* Center mark */}
      <circle cx="200" cy="200" r="36" fill="#163A2E" />
      <path
        d="M200 186c-7 0-13 6-13 13 0 10 13 21 13 21s13-11 13-21c0-7-6-13-13-13Z"
        fill="#6FCF97"
      />
    </svg>
  );
};

export default MacroRing;
