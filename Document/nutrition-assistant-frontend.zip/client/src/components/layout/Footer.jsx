import React from "react";
import { Link } from "react-router-dom";
import { HiOutlineMail } from "react-icons/hi";
import { FaGithub, FaLinkedin, FaTwitter } from "react-icons/fa";

const footerLinks = [
  {
    heading: "Product",
    links: [
      { label: "How it works", href: "/#how-it-works" },
      { label: "Nutrients tracked", href: "/#nutrients" },
      { label: "Log in", href: "/login" },
      { label: "Create account", href: "/register" },
    ],
  },
  {
    heading: "Project",
    links: [
      { label: "About this project", href: "/#about" },
      { label: "Tech stack", href: "/#tech" },
    ],
  },
];

const Footer = () => {
  const year = new Date().getFullYear();

  return (
    <footer className="border-t border-forest/10 bg-forest text-white">
      <div className="mx-auto max-w-7xl px-6 py-14 lg:px-8">
        <div className="grid grid-cols-1 gap-10 md:grid-cols-[1.4fr,1fr,1fr]">
          {/* Brand column */}
          <div>
            <Link to="/" className="flex items-center gap-2">
              <svg width="30" height="30" viewBox="0 0 32 32" fill="none" aria-hidden="true">
                <circle cx="16" cy="16" r="15" fill="#FFFFFF" fillOpacity="0.08" />
                <circle cx="16" cy="16" r="10.5" stroke="#6FCF97" strokeWidth="2.5" />
                <circle cx="16" cy="16" r="4.5" fill="#6FCF97" />
              </svg>
              <span className="font-display text-lg font-semibold text-white">
                Nutrition Assistant
              </span>
            </Link>
            <p className="mt-4 max-w-xs font-body text-sm leading-relaxed text-white/70">
              A simple, science-informed way to log meals, understand your
              nutrients, and build habits that stick.
            </p>
            <div className="mt-6 flex items-center gap-4 text-white/70">
              <a href="#" aria-label="GitHub" className="transition-colors hover:text-fresh">
                <FaGithub size={18} />
              </a>
              <a href="#" aria-label="LinkedIn" className="transition-colors hover:text-fresh">
                <FaLinkedin size={18} />
              </a>
              <a href="#" aria-label="Twitter" className="transition-colors hover:text-fresh">
                <FaTwitter size={18} />
              </a>
              <a href="mailto:hello@nutritionassistant.app" aria-label="Email" className="transition-colors hover:text-fresh">
                <HiOutlineMail size={20} />
              </a>
            </div>
          </div>

          {/* Link columns */}
          {footerLinks.map((col) => (
            <div key={col.heading}>
              <h4 className="font-body text-sm font-semibold uppercase tracking-wide text-fresh">
                {col.heading}
              </h4>
              <ul className="mt-4 space-y-3">
                {col.links.map((link) => (
                  <li key={link.label}>
                    <a
                      href={link.href}
                      className="font-body text-sm text-white/70 transition-colors hover:text-white"
                    >
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-white/10 pt-6 text-xs text-white/50 md:flex-row">
          <p>© {year} Nutrition Assistant. Built as a MERN stack college major project.</p>
          <p>Made with React · Express · MongoDB</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
