import React, { useState } from "react";
import { Link, NavLink, useNavigate } from "react-router-dom";
import { HiMenu, HiX } from "react-icons/hi";
import { useAuth } from "../../context/AuthContext.jsx";

const navLinks = [
  { label: "Home", href: "/" },
  { label: "Nutrients", href: "/#nutrients" },
  { label: "How it works", href: "/#how-it-works" },
];

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const { isAuthenticated, user, logout } = useAuth();
  const navigate = useNavigate();

  const closeMenu = () => setIsOpen(false);

  const handleLogout = () => {
    logout();
    closeMenu();
    navigate("/");
  };

  return (
    <header className="sticky top-0 z-50 border-b border-forest/10 bg-white/90 backdrop-blur">
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-6 py-4 lg:px-8">
        {/* Logo */}
        <Link to="/" className="flex items-center gap-2" onClick={closeMenu}>
          <svg width="32" height="32" viewBox="0 0 32 32" fill="none" aria-hidden="true">
            <circle cx="16" cy="16" r="15" fill="#163A2E" />
            <circle cx="16" cy="16" r="10.5" stroke="#6FCF97" strokeWidth="2.5" />
            <circle cx="16" cy="16" r="4.5" fill="#6FCF97" />
          </svg>
          <span className="font-display text-xl font-semibold text-forest">
            Nutrition<span className="text-brand">Assistant</span>
          </span>
        </Link>

        {/* Desktop nav links */}
        <div className="hidden items-center gap-8 md:flex">
          {navLinks.map((link) => (
            <a
              key={link.label}
              href={link.href}
              className="font-body text-sm font-medium text-ink/80 transition-colors hover:text-brand"
            >
              {link.label}
            </a>
          ))}
        </div>

        {/* Desktop auth actions */}
        <div className="hidden items-center gap-3 md:flex">
          {isAuthenticated ? (
            <>
              <NavLink
                to="/home"
                className="font-body text-sm font-medium text-ink/80 transition-colors hover:text-brand"
              >
                Hi, {user?.name?.split(" ")[0] || "there"}
              </NavLink>
              <button onClick={handleLogout} className="btn-secondary !px-5 !py-2 text-sm">
                Log out
              </button>
            </>
          ) : (
            <>
              <Link to="/login" className="font-body text-sm font-medium text-ink/80 transition-colors hover:text-brand">
                Log in
              </Link>
              <Link to="/register" className="btn-primary !px-5 !py-2 text-sm">
                Get started
              </Link>
            </>
          )}
        </div>

        {/* Mobile menu toggle */}
        <button
          type="button"
          className="inline-flex items-center justify-center rounded-lg p-2 text-forest md:hidden"
          aria-expanded={isOpen}
          aria-label="Toggle navigation menu"
          onClick={() => setIsOpen((prev) => !prev)}
        >
          {isOpen ? <HiX size={26} /> : <HiMenu size={26} />}
        </button>
      </nav>

      {/* Mobile menu panel */}
      {isOpen && (
        <div className="border-t border-forest/10 bg-white px-6 pb-6 md:hidden">
          <div className="flex flex-col gap-4 pt-4">
            {navLinks.map((link) => (
              <a
                key={link.label}
                href={link.href}
                onClick={closeMenu}
                className="font-body text-base font-medium text-ink/80 hover:text-brand"
              >
                {link.label}
              </a>
            ))}

            <hr className="border-forest/10" />

            {isAuthenticated ? (
              <>
                <Link to="/home" onClick={closeMenu} className="font-body text-base font-medium text-ink/80 hover:text-brand">
                  Hi, {user?.name?.split(" ")[0] || "there"}
                </Link>
                <button onClick={handleLogout} className="btn-secondary w-full">
                  Log out
                </button>
              </>
            ) : (
              <>
                <Link to="/login" onClick={closeMenu} className="btn-secondary w-full">
                  Log in
                </Link>
                <Link to="/register" onClick={closeMenu} className="btn-primary w-full">
                  Get started
                </Link>
              </>
            )}
          </div>
        </div>
      )}
    </header>
  );
};

export default Navbar;
