import api from "./api";

/**
 * Registers a new user.
 * @param {{name: string, email: string, password: string}} payload
 */
const register = async (payload) => {
  const { data } = await api.post("/auth/register", payload);
  return data.data; // { user, token }
};

/**
 * Logs in an existing user.
 * @param {{email: string, password: string}} payload
 */
const login = async (payload) => {
  const { data } = await api.post("/auth/login", payload);
  return data.data; // { user, token }
};

/**
 * Fetches the currently authenticated user's basic info.
 */
const getMe = async () => {
  const { data } = await api.get("/auth/me");
  return data.data.user;
};

const authService = { register, login, getMe };

export default authService;
