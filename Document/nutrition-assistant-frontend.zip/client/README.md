# Nutrition Assistant App — Frontend

React + Vite + Tailwind CSS + React Router + Axios.

## Setup

1. Install dependencies:
   ```
   npm install
   ```

2. Create a `.env` file (copy from `.env.example`):
   ```
   VITE_API_URL=http://localhost:5000/api
   ```

3. Run the dev server:
   ```
   npm run dev
   ```
   App runs at `http://localhost:5173`. Make sure the backend server (from the `server/` folder) is running at `http://localhost:5000`.

4. Build for production:
   ```
   npm run build
   ```

## Pages included in this phase

| Route       | Page          | Access    |
|-------------|---------------|-----------|
| `/`         | Landing Page   | Public    |
| `/login`    | Login Page     | Public    |
| `/register` | Register Page  | Public    |
| `/home`     | Home Page      | Private (redirects to `/login` if not authenticated) |

Dashboard and meal-logging features will be added in a later phase.

## Design system

- **Palette:** deep forest green (`#163A2E`) for headings/dark sections, brand green (`#2F6F4E`) for actions, fresh green (`#6FCF97`) as an accent, mist (`#EAF6EF`) and white for backgrounds.
- **Type:** `Fraunces` (display/serif) for headings, `Inter` (sans) for body and UI text.
- **Signature element:** the `MacroRing` component — a concentric-ring graphic inspired by a nutrition label's macro breakdown (protein / carbs / fats), reused across the hero, login, and register pages.
- All interactive elements have visible keyboard focus states and the layout is fully responsive (mobile, tablet, desktop).

## Folder Structure

```
client/
├── src/
│   ├── components/
│   │   ├── layout/       # Navbar, Footer, Layout
│   │   └── ui/           # MacroRing (signature graphic)
│   ├── context/          # AuthContext (global auth state)
│   ├── pages/             # LandingPage, HomePage, LoginPage, RegisterPage, NotFoundPage
│   ├── routes/            # ProtectedRoute
│   ├── services/          # api.js (axios instance), authService.js
│   ├── utils/              # validators.js
│   ├── App.jsx
│   ├── main.jsx
│   └── index.css
├── index.html
├── tailwind.config.js
├── postcss.config.js
└── vite.config.js
```
