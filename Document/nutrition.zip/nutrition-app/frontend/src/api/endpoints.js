import client from './client';

export const AuthAPI = {
  register: (data) => client.post('/auth/register', data).then(r => r.data),
  login: (data) => client.post('/auth/login', data).then(r => r.data),
  me: () => client.get('/auth/me').then(r => r.data),
  updateProfile: (data) => client.put('/auth/profile', data).then(r => r.data)
};

export const AssistantAPI = {
  chat: (message) => client.post('/assistant/chat', { message }).then(r => r.data),
  history: () => client.get('/assistant/history').then(r => r.data)
};

export const RecipesAPI = {
  list: (params) => client.get('/recipes', { params }).then(r => r.data),
  get: (id) => client.get(`/recipes/${id}`).then(r => r.data),
  create: (data) => client.post('/recipes', data).then(r => r.data),
  update: (id, data) => client.put(`/recipes/${id}`, data).then(r => r.data),
  remove: (id) => client.delete(`/recipes/${id}`).then(r => r.data),
  logEaten: (id) => client.post(`/recipes/${id}/log`, {}).then(r => r.data)
};

export const GroceryAPI = {
  get: () => client.get('/grocery').then(r => r.data),
  addItem: (data) => client.post('/grocery/items', data).then(r => r.data),
  updateItem: (id, data) => client.put(`/grocery/items/${id}`, data).then(r => r.data),
  removeItem: (id) => client.delete(`/grocery/items/${id}`).then(r => r.data),
  addFromRecipe: (recipeId) => client.post(`/grocery/from-recipe/${recipeId}`).then(r => r.data),
  clear: () => client.delete('/grocery/clear').then(r => r.data)
};

export const TipsAPI = {
  list: (params) => client.get('/tips', { params }).then(r => r.data),
  random: () => client.get('/tips/random').then(r => r.data),
  create: (data) => client.post('/tips', data).then(r => r.data),
  update: (id, data) => client.put(`/tips/${id}`, data).then(r => r.data),
  remove: (id) => client.delete(`/tips/${id}`).then(r => r.data)
};

export const AnalyticsAPI = {
  dashboard: () => client.get('/analytics/dashboard').then(r => r.data),
  weekly: () => client.get('/analytics/weekly').then(r => r.data),
  monthly: () => client.get('/analytics/monthly').then(r => r.data)
};

export const AdminAPI = {
  listUsers: () => client.get('/admin/users').then(r => r.data),
  updateRole: (id, role) => client.put(`/admin/users/${id}/role`, { role }).then(r => r.data),
  removeUser: (id) => client.delete(`/admin/users/${id}`).then(r => r.data),
  stats: () => client.get('/admin/stats').then(r => r.data)
};
