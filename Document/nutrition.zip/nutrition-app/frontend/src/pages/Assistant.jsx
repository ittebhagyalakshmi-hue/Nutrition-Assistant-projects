import { useEffect, useRef, useState } from 'react';
import { AssistantAPI } from '../api/endpoints';

export default function Assistant() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [sending, setSending] = useState(false);
  const [error, setError] = useState('');
  const bottomRef = useRef(null);

  useEffect(() => {
    AssistantAPI.history().then((data) => {
      const loaded = data.history.flatMap((h) => ([
        { role: 'user', content: h.message },
        { role: 'assistant', content: h.reply }
      ]));
      setMessages(loaded);
    }).catch(() => {});
  }, []);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async (e) => {
    e.preventDefault();
    if (!input.trim() || sending) return;
    setError('');

    const userMessage = input.trim();
    setMessages((prev) => [...prev, { role: 'user', content: userMessage }]);
    setInput('');
    setSending(true);

    try {
      const data = await AssistantAPI.chat(userMessage);
      setMessages((prev) => [...prev, { role: 'assistant', content: data.reply }]);
    } catch (err) {
      setError(err.response?.data?.error || 'The assistant is unavailable right now.');
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="page-container assistant-page">
      <h1>AI Nutrition Assistant</h1>
      <p className="page-subtitle">Ask about meals, macros, healthy swaps, or planning your week.</p>

      <div className="chat-window">
        {messages.length === 0 && (
          <div className="empty-state">Try asking: "What's a high-protein breakfast under 400 calories?"</div>
        )}
        {messages.map((m, i) => (
          <div key={i} className={`chat-bubble ${m.role}`}>
            <span className="chat-role">{m.role === 'user' ? 'You' : 'Assistant'}</span>
            <p>{m.content}</p>
          </div>
        ))}
        {sending && <div className="chat-bubble assistant chat-typing">Thinking...</div>}
        <div ref={bottomRef} />
      </div>

      {error && <div className="auth-error">{error}</div>}

      <form className="chat-input-row" onSubmit={handleSend}>
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask the nutrition assistant..."
          disabled={sending}
        />
        <button type="submit" disabled={sending || !input.trim()}>Send</button>
      </form>
    </div>
  );
}
