import { useEffect, useState } from 'react';
import { TipsAPI } from '../api/endpoints';

export default function Tips() {
  const [tips, setTips] = useState([]);
  const [featured, setFeatured] = useState(null);

  useEffect(() => {
    TipsAPI.list().then((data) => setTips(data.tips));
    TipsAPI.random().then((data) => setFeatured(data.tip)).catch(() => {});
  }, []);

  return (
    <div className="page-container">
      <h1>Nutrition Tips</h1>

      {featured && (
        <div className="featured-tip">
          <span className="tip-badge">Tip of the moment</span>
          <h2>{featured.title}</h2>
          <p>{featured.content}</p>
        </div>
      )}

      <div className="tips-grid">
        {tips.map((tip) => (
          <div key={tip.id} className="tip-card">
            <span className="recipe-category">{tip.category}</span>
            <h3>{tip.title}</h3>
            <p>{tip.content}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
