import { useEffect, useState } from 'react';
import { RecipesAPI, GroceryAPI } from '../api/endpoints';

export default function Recipes() {
  const [recipes, setRecipes] = useState([]);
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState(null);
  const [toast, setToast] = useState('');

  const load = () => {
    RecipesAPI.list(search ? { search } : {}).then((data) => setRecipes(data.recipes));
  };

  useEffect(() => { load(); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const handleSearch = (e) => {
    e.preventDefault();
    load();
  };

  const showToast = (msg) => {
    setToast(msg);
    setTimeout(() => setToast(''), 2500);
  };

  const logRecipe = async (id) => {
    await RecipesAPI.logEaten(id);
    showToast('Logged to your nutrition history!');
  };

  const addToGrocery = async (id) => {
    await GroceryAPI.addFromRecipe(id);
    showToast('Ingredients added to grocery list!');
  };

  return (
    <div className="page-container">
      <h1>Healthy Recipes</h1>

      <form className="search-row" onSubmit={handleSearch}>
        <input
          placeholder="Search recipes or tags (e.g. vegan, high-protein)"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
        <button type="submit">Search</button>
      </form>

      {toast && <div className="toast">{toast}</div>}

      <div className="recipe-grid">
        {recipes.map((r) => (
          <div key={r.id} className="recipe-card" onClick={() => setSelected(r)}>
            <h3>{r.title}</h3>
            <span className="recipe-category">{r.category}</span>
            <div className="recipe-macros">
              <span>{r.calories} kcal</span>
              <span>{r.protein}g protein</span>
              <span>{r.carbs}g carbs</span>
              <span>{r.fat}g fat</span>
            </div>
            <div className="recipe-tags">
              {r.tags.map((t) => <span key={t} className="tag">{t}</span>)}
            </div>
          </div>
        ))}
        {recipes.length === 0 && <p className="empty-state">No recipes found.</p>}
      </div>

      {selected && (
        <div className="modal-backdrop" onClick={() => setSelected(null)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <button className="modal-close" onClick={() => setSelected(null)}>×</button>
            <h2>{selected.title}</h2>
            <span className="recipe-category">{selected.category}</span>
            <div className="recipe-macros">
              <span>{selected.calories} kcal</span>
              <span>{selected.protein}g protein</span>
              <span>{selected.carbs}g carbs</span>
              <span>{selected.fat}g fat</span>
            </div>
            <h4>Ingredients</h4>
            <ul>{selected.ingredients.map((i, idx) => <li key={idx}>{i}</li>)}</ul>
            <h4>Steps</h4>
            <ol>{selected.steps.map((s, idx) => <li key={idx}>{s}</li>)}</ol>
            <div className="modal-actions">
              <button onClick={() => logRecipe(selected.id)}>Log as eaten</button>
              <button onClick={() => addToGrocery(selected.id)}>Add ingredients to grocery list</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
