import { useEffect, useState } from 'react';
import { GroceryAPI } from '../api/endpoints';

export default function GroceryList() {
  const [list, setList] = useState({ items: [] });
  const [form, setForm] = useState({ name: '', quantity: '', category: '' });

  const load = () => GroceryAPI.get().then((data) => setList(data.list));

  useEffect(() => { load(); }, []);

  const handleAdd = async (e) => {
    e.preventDefault();
    if (!form.name.trim()) return;
    await GroceryAPI.addItem(form);
    setForm({ name: '', quantity: '', category: '' });
    load();
  };

  const toggleChecked = async (item) => {
    await GroceryAPI.updateItem(item.id, { checked: !item.checked });
    load();
  };

  const removeItem = async (id) => {
    await GroceryAPI.removeItem(id);
    load();
  };

  const clearAll = async () => {
    await GroceryAPI.clear();
    load();
  };

  const grouped = list.items.reduce((acc, item) => {
    acc[item.category] = acc[item.category] || [];
    acc[item.category].push(item);
    return acc;
  }, {});

  return (
    <div className="page-container">
      <h1>Grocery List</h1>

      <form className="grocery-form" onSubmit={handleAdd}>
        <input
          placeholder="Item name"
          value={form.name}
          onChange={(e) => setForm({ ...form, name: e.target.value })}
        />
        <input
          placeholder="Qty"
          value={form.quantity}
          onChange={(e) => setForm({ ...form, quantity: e.target.value })}
        />
        <input
          placeholder="Category"
          value={form.category}
          onChange={(e) => setForm({ ...form, category: e.target.value })}
        />
        <button type="submit">Add</button>
      </form>

      {list.items.length > 0 && (
        <button className="clear-btn" onClick={clearAll}>Clear all</button>
      )}

      {Object.keys(grouped).length === 0 && <p className="empty-state">Your grocery list is empty.</p>}

      {Object.entries(grouped).map(([category, items]) => (
        <div key={category} className="grocery-group">
          <h3>{category}</h3>
          <ul className="grocery-items">
            {items.map((item) => (
              <li key={item.id} className={item.checked ? 'checked' : ''}>
                <label>
                  <input type="checkbox" checked={item.checked} onChange={() => toggleChecked(item)} />
                  {item.name} <span className="grocery-qty">({item.quantity})</span>
                </label>
                <button className="remove-btn" onClick={() => removeItem(item.id)}>Remove</button>
              </li>
            ))}
          </ul>
        </div>
      ))}
    </div>
  );
}
