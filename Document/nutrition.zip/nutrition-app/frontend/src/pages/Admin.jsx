import { useEffect, useState } from 'react';
import { AdminAPI, RecipesAPI, TipsAPI } from '../api/endpoints';

export default function Admin() {
  const [tab, setTab] = useState('stats');
  const [stats, setStats] = useState(null);
  const [users, setUsers] = useState([]);
  const [recipes, setRecipes] = useState([]);
  const [tips, setTips] = useState([]);
  const [recipeForm, setRecipeForm] = useState({ title: '', category: '', calories: '', protein: '', carbs: '', fat: '', ingredients: '', steps: '', tags: '' });
  const [tipForm, setTipForm] = useState({ category: '', title: '', content: '' });

  const loadAll = () => {
    AdminAPI.stats().then(setStats);
    AdminAPI.listUsers().then((d) => setUsers(d.users));
    RecipesAPI.list().then((d) => setRecipes(d.recipes));
    TipsAPI.list().then((d) => setTips(d.tips));
  };

  useEffect(() => { loadAll(); }, []);

  const changeRole = async (id, role) => {
    await AdminAPI.updateRole(id, role);
    loadAll();
  };

  const deleteUser = async (id) => {
    await AdminAPI.removeUser(id);
    loadAll();
  };

  const createRecipe = async (e) => {
    e.preventDefault();
    await RecipesAPI.create({
      ...recipeForm,
      calories: Number(recipeForm.calories),
      protein: Number(recipeForm.protein),
      carbs: Number(recipeForm.carbs),
      fat: Number(recipeForm.fat),
      ingredients: recipeForm.ingredients.split(',').map((s) => s.trim()).filter(Boolean),
      steps: recipeForm.steps.split(',').map((s) => s.trim()).filter(Boolean),
      tags: recipeForm.tags.split(',').map((s) => s.trim()).filter(Boolean)
    });
    setRecipeForm({ title: '', category: '', calories: '', protein: '', carbs: '', fat: '', ingredients: '', steps: '', tags: '' });
    loadAll();
  };

  const deleteRecipe = async (id) => {
    await RecipesAPI.remove(id);
    loadAll();
  };

  const createTip = async (e) => {
    e.preventDefault();
    await TipsAPI.create(tipForm);
    setTipForm({ category: '', title: '', content: '' });
    loadAll();
  };

  const deleteTip = async (id) => {
    await TipsAPI.remove(id);
    loadAll();
  };

  return (
    <div className="page-container">
      <h1>Admin Panel</h1>

      <div className="chart-toggle admin-tabs">
        <button className={tab === 'stats' ? 'active' : ''} onClick={() => setTab('stats')}>Platform Stats</button>
        <button className={tab === 'users' ? 'active' : ''} onClick={() => setTab('users')}>Users</button>
        <button className={tab === 'recipes' ? 'active' : ''} onClick={() => setTab('recipes')}>Recipes</button>
        <button className={tab === 'tips' ? 'active' : ''} onClick={() => setTab('tips')}>Tips</button>
      </div>

      {tab === 'stats' && stats && (
        <div className="stat-cards">
          <div className="stat-card"><h3>Total Users</h3><p className="stat-value">{stats.totalUsers}</p></div>
          <div className="stat-card"><h3>Admins</h3><p className="stat-value">{stats.totalAdmins}</p></div>
          <div className="stat-card"><h3>Recipes</h3><p className="stat-value">{stats.totalRecipes}</p></div>
          <div className="stat-card"><h3>Tips</h3><p className="stat-value">{stats.totalTips}</p></div>
          <div className="stat-card"><h3>Nutrition Logs</h3><p className="stat-value">{stats.totalNutritionLogs}</p></div>
          <div className="stat-card"><h3>Assistant Chats</h3><p className="stat-value">{stats.totalAssistantChats}</p></div>
        </div>
      )}

      {tab === 'users' && (
        <table className="admin-table">
          <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Actions</th></tr></thead>
          <tbody>
            {users.map((u) => (
              <tr key={u.id}>
                <td>{u.name}</td>
                <td>{u.email}</td>
                <td>{u.role}</td>
                <td>
                  <button onClick={() => changeRole(u.id, u.role === 'admin' ? 'user' : 'admin')}>
                    Make {u.role === 'admin' ? 'User' : 'Admin'}
                  </button>
                  <button className="remove-btn" onClick={() => deleteUser(u.id)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {tab === 'recipes' && (
        <div>
          <form className="admin-form" onSubmit={createRecipe}>
            <h3>Add Recipe</h3>
            <input placeholder="Title" value={recipeForm.title} onChange={(e) => setRecipeForm({ ...recipeForm, title: e.target.value })} required />
            <input placeholder="Category" value={recipeForm.category} onChange={(e) => setRecipeForm({ ...recipeForm, category: e.target.value })} required />
            <input placeholder="Calories" type="number" value={recipeForm.calories} onChange={(e) => setRecipeForm({ ...recipeForm, calories: e.target.value })} />
            <input placeholder="Protein (g)" type="number" value={recipeForm.protein} onChange={(e) => setRecipeForm({ ...recipeForm, protein: e.target.value })} />
            <input placeholder="Carbs (g)" type="number" value={recipeForm.carbs} onChange={(e) => setRecipeForm({ ...recipeForm, carbs: e.target.value })} />
            <input placeholder="Fat (g)" type="number" value={recipeForm.fat} onChange={(e) => setRecipeForm({ ...recipeForm, fat: e.target.value })} />
            <input placeholder="Ingredients (comma separated)" value={recipeForm.ingredients} onChange={(e) => setRecipeForm({ ...recipeForm, ingredients: e.target.value })} />
            <input placeholder="Steps (comma separated)" value={recipeForm.steps} onChange={(e) => setRecipeForm({ ...recipeForm, steps: e.target.value })} />
            <input placeholder="Tags (comma separated)" value={recipeForm.tags} onChange={(e) => setRecipeForm({ ...recipeForm, tags: e.target.value })} />
            <button type="submit">Create Recipe</button>
          </form>
          <ul className="admin-list">
            {recipes.map((r) => (
              <li key={r.id}>{r.title} ({r.category}) <button className="remove-btn" onClick={() => deleteRecipe(r.id)}>Delete</button></li>
            ))}
          </ul>
        </div>
      )}

      {tab === 'tips' && (
        <div>
          <form className="admin-form" onSubmit={createTip}>
            <h3>Add Tip</h3>
            <input placeholder="Category" value={tipForm.category} onChange={(e) => setTipForm({ ...tipForm, category: e.target.value })} required />
            <input placeholder="Title" value={tipForm.title} onChange={(e) => setTipForm({ ...tipForm, title: e.target.value })} required />
            <textarea placeholder="Content" value={tipForm.content} onChange={(e) => setTipForm({ ...tipForm, content: e.target.value })} required />
            <button type="submit">Create Tip</button>
          </form>
          <ul className="admin-list">
            {tips.map((t) => (
              <li key={t.id}>{t.title} ({t.category}) <button className="remove-btn" onClick={() => deleteTip(t.id)}>Delete</button></li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}
