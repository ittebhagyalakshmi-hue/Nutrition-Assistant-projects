import { useEffect, useState } from 'react';
import {
  ResponsiveContainer, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend
} from 'recharts';
import { AnalyticsAPI } from '../api/endpoints';
import { useAuth } from '../context/AuthContext';

export default function Dashboard() {
  const { user } = useAuth();
  const [data, setData] = useState(null);
  const [range, setRange] = useState('weekly');
  const [error, setError] = useState('');

  useEffect(() => {
    AnalyticsAPI.dashboard()
      .then(setData)
      .catch(() => setError('Could not load dashboard analytics.'));
  }, []);

  if (error) return <div className="page-container"><p className="error-text">{error}</p></div>;
  if (!data) return <div className="page-container">Loading dashboard...</div>;

  const chart = range === 'weekly' ? data.weekly.chart : data.monthly.chart;

  return (
    <div className="page-container">
      <h1>Hi {user?.name?.split(' ')[0]}, here's your overview</h1>

      <div className="stat-cards">
        <div className="stat-card">
          <h3>Today's Calories</h3>
          <p className="stat-value">{data.today.calories}</p>
          <span className="stat-target">Target: {data.profile.dailyCalorieTarget}</span>
        </div>
        <div className="stat-card">
          <h3>Meals Logged Today</h3>
          <p className="stat-value">{data.today.mealsLogged}</p>
        </div>
        <div className="stat-card">
          <h3>Weekly Avg Calories</h3>
          <p className="stat-value">{data.weekly.avgCalories}</p>
        </div>
        <div className="stat-card">
          <h3>Grocery Items Pending</h3>
          <p className="stat-value">{data.groceryPending}</p>
        </div>
      </div>

      <div className="chart-panel">
        <div className="chart-panel-header">
          <h2>Calorie Trend</h2>
          <div className="chart-toggle">
            <button className={range === 'weekly' ? 'active' : ''} onClick={() => setRange('weekly')}>Weekly</button>
            <button className={range === 'monthly' ? 'active' : ''} onClick={() => setRange('monthly')}>Monthly</button>
          </div>
        </div>
        {chart.length === 0 ? (
          <p className="empty-state">No nutrition logs yet — log a recipe from the Recipes page to see your trend.</p>
        ) : (
          <ResponsiveContainer width="100%" height={320}>
            <LineChart data={chart}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="calories" stroke="#2f9e44" strokeWidth={2} />
              <Line type="monotone" dataKey="protein" stroke="#1971c2" strokeWidth={2} />
              <Line type="monotone" dataKey="carbs" stroke="#e8590c" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        )}
      </div>
    </div>
  );
}
