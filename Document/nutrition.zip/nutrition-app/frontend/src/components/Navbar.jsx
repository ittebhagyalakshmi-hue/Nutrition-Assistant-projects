import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  if (!user) return null;

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <nav className="navbar">
      <div className="navbar-brand">🥗 Nutrition Assistant</div>
      <div className="navbar-links">
        <Link to="/dashboard">Dashboard</Link>
        <Link to="/assistant">AI Assistant</Link>
        <Link to="/recipes">Recipes</Link>
        <Link to="/grocery">Grocery List</Link>
        <Link to="/tips">Tips</Link>
        {user.role === 'admin' && <Link to="/admin">Admin</Link>}
      </div>
      <div className="navbar-user">
        <span>{user.name}</span>
        <button onClick={handleLogout}>Logout</button>
      </div>
    </nav>
  );
}
