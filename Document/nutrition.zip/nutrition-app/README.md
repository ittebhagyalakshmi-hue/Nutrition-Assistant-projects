# Nutrition Assistant App

A full-stack nutrition tracking application with an AI-powered nutrition assistant, healthy recipes, grocery lists, nutrition tips, analytics charts, and an admin panel.

**Stack:** Node.js / Express backend (JSON file storage via `lowdb`, no external database required) + React (Vite) frontend, JWT authentication, Google Gemini API for the AI assistant.

---

## 1. Features

| # | Module | Description |
|---|--------|-------------|
| 1 | AI Nutrition Assistant | Chat interface backed by the Gemini API, with per-user conversation history |
| 2 | Healthy Recipes | Browsable/searchable recipe library with macros, ingredients, and steps |
| 3 | Grocery List | Personal grocery list, manual items, or auto-added from a recipe's ingredients |
| 4 | Nutrition Tips | Categorized tips plus a "tip of the moment" |
| 5 | Weekly & Monthly Charts | Line charts of calories/protein/carbs, built from logged meals |
| 6 | Admin Panel | Manage users/roles, recipes, and tips |
| 7 | Dashboard Analytics | Daily/weekly/monthly summary, grocery status, assistant usage |
| 8 | API Integration | Single REST API consumed by the React frontend via Axios |
| 9 | Authentication Flow | JWT register/login, protected routes, admin-only routes |
| 10 | Testing | Jest + Supertest integration tests covering every backend module |
| 11 | README / Install / Deploy | This document |

## 2. Project Structure

```
nutrition-app/
├── backend/
│   ├── server.js              # Express app entry point
│   ├── models/
│   │   ├── db.js              # lowdb (file-based JSON) setup
│   │   └── seed.js            # Seeds sample recipes & tips on first run
│   ├── middleware/
│   │   ├── auth.js            # JWT auth + admin guard
│   │   └── errorHandler.js
│   ├── routes/
│   │   ├── auth.js            # register / login / me / profile
│   │   ├── assistant.js       # Gemini-powered chat
│   │   ├── recipes.js
│   │   ├── grocery.js
│   │   ├── tips.js
│   │   ├── analytics.js       # dashboard + weekly/monthly chart data
│   │   └── admin.js
│   ├── tests/
│   │   └── api.test.js        # Jest/Supertest tests for every module
│   ├── data/                  # auto-created JSON "database" file
│   └── .env.example
└── frontend/
    ├── src/
    │   ├── api/                # axios client + typed endpoint calls
    │   ├── context/AuthContext.jsx
    │   ├── components/          # Navbar, ProtectedRoute, AdminRoute
    │   ├── pages/                # Login, Register, Dashboard, Assistant,
    │   │                          # Recipes, GroceryList, Tips, Admin
    │   ├── App.jsx
    │   ├── main.jsx
    │   └── styles.css
    ├── index.html
    ├── vite.config.js
    └── .env.example
```

## 3. How the pieces connect

- The **frontend** never talks to Gemini directly — it calls `/api/assistant/chat` on **your** backend, which holds the Gemini API key server-side. This keeps your key out of the browser.
- Every frontend request goes through `src/api/client.js`, which attaches the JWT from `localStorage` automatically and redirects to `/login` on a 401.
- `vite.config.js` proxies `/api/*` to `http://localhost:5000` in development, so the frontend can call relative paths like `/api/recipes` without CORS issues locally.
- Logging a recipe as "eaten" (Recipes page) writes a `nutritionLogs` entry, which is what powers the Dashboard's weekly/monthly charts and daily calorie totals.

---

## 4. Installation

### Prerequisites
- Node.js 18+ and npm
- A free Gemini API key from [Google AI Studio](https://aistudio.google.com/app/apikey)

### Backend setup
```bash
cd backend
npm install
cp .env.example .env
```
Edit `backend/.env`:
```
PORT=5000
JWT_SECRET=<generate a long random string>
JWT_EXPIRES_IN=7d
GEMINI_API_KEY=<your Gemini API key>
GEMINI_MODEL=gemini-1.5-flash
ADMIN_SIGNUP_CODE=<a secret code of your choosing>
CORS_ORIGIN=http://localhost:5173
```
Run it:
```bash
npm run dev      # nodemon, auto-restarts on changes
# or
npm start
```
The API starts on `http://localhost:5000`. Sample recipes and tips are seeded automatically on first run.

### Frontend setup
```bash
cd frontend
npm install
cp .env.example .env
```
Edit `frontend/.env` if your backend isn't on the default port:
```
VITE_API_BASE_URL=http://localhost:5000/api
```
Run it:
```bash
npm run dev
```
Open `http://localhost:5173`.

### Creating an admin account
Register normally, but include the `ADMIN_SIGNUP_CODE` you set in `backend/.env` in the "Admin code" field on the sign-up page. Accounts registered without it get the regular `user` role. You can also promote any user to admin later from the Admin Panel (once at least one admin exists).

---

## 5. Running Tests

```bash
cd backend
npm test
```
This runs the full Jest/Supertest suite covering auth, recipes, grocery list, tips, analytics, admin routes, and assistant error handling, against an isolated test database file that is created and torn down automatically.

---

## 6. Deployment Guide

### Backend (e.g. Render, Railway, Fly.io, or a VPS)
1. Push the `backend/` folder to a Git repo (or the whole monorepo).
2. Create a new Node web service, root directory `backend`.
3. Build command: `npm install`. Start command: `npm start`.
4. Set environment variables in the host's dashboard (same keys as `.env.example`). Set `CORS_ORIGIN` to your deployed frontend's URL.
5. Note: `lowdb` writes to a local JSON file (`backend/data/db.json`). This works for a single-instance deployment, but the filesystem on most PaaS platforms is **ephemeral** (wiped on redeploy) — mount a persistent volume/disk if your host supports one, or later swap `models/db.js` for a hosted database (e.g. MongoDB Atlas, Postgres) if you need durable multi-instance storage.

### Frontend (e.g. Vercel, Netlify)
1. Root directory `frontend`. Build command: `npm run build`. Output directory: `dist`.
2. Set the environment variable `VITE_API_BASE_URL` to your deployed backend's URL, e.g. `https://your-backend.onrender.com/api`.
3. Deploy. Update the backend's `CORS_ORIGIN` to match the deployed frontend domain and redeploy the backend.

### Post-deploy checklist
- [ ] `GET https://your-backend-url/api/health` returns `{ "status": "ok" }`
- [ ] Register a test account on the deployed frontend and confirm login works
- [ ] Confirm the AI Assistant responds (requires a valid `GEMINI_API_KEY` on the backend)
- [ ] Confirm charts render after logging a recipe as eaten

---

## 7. Security notes
- Passwords are hashed with bcrypt; never stored in plaintext.
- JWTs are signed with `JWT_SECRET` — use a long, random value in production and never commit `.env`.
- The Gemini API key lives only on the backend.
- Admin signup is gated behind a server-side `ADMIN_SIGNUP_CODE` — keep it private and rotate it if it leaks.
