process.env.NODE_ENV = 'test';
process.env.JWT_SECRET = 'test_secret';
process.env.ADMIN_SIGNUP_CODE = 'test_admin_code';

const fs = require('fs');
const path = require('path');
const request = require('supertest');

const testDbPath = path.join(__dirname, '..', 'data', 'test-db.json');

beforeAll(() => {
  if (fs.existsSync(testDbPath)) fs.unlinkSync(testDbPath);
});

afterAll(() => {
  if (fs.existsSync(testDbPath)) fs.unlinkSync(testDbPath);
});

const app = require('../server');

let userToken;
let adminToken;
let recipeId;

describe('Health check', () => {
  it('GET /api/health returns ok', async () => {
    const res = await request(app).get('/api/health');
    expect(res.statusCode).toBe(200);
    expect(res.body.status).toBe('ok');
  });
});

describe('Auth flow', () => {
  it('registers a new user', async () => {
    const res = await request(app).post('/api/auth/register').send({
      name: 'Test User',
      email: 'user@test.com',
      password: 'password123'
    });
    expect(res.statusCode).toBe(201);
    expect(res.body.token).toBeDefined();
    expect(res.body.user.role).toBe('user');
    userToken = res.body.token;
  });

  it('registers an admin user with valid admin code', async () => {
    const res = await request(app).post('/api/auth/register').send({
      name: 'Admin User',
      email: 'admin@test.com',
      password: 'password123',
      adminCode: 'test_admin_code'
    });
    expect(res.statusCode).toBe(201);
    expect(res.body.user.role).toBe('admin');
    adminToken = res.body.token;
  });

  it('rejects duplicate registration', async () => {
    const res = await request(app).post('/api/auth/register').send({
      name: 'Test User',
      email: 'user@test.com',
      password: 'password123'
    });
    expect(res.statusCode).toBe(409);
  });

  it('logs in with correct credentials', async () => {
    const res = await request(app).post('/api/auth/login').send({
      email: 'user@test.com',
      password: 'password123'
    });
    expect(res.statusCode).toBe(200);
    expect(res.body.token).toBeDefined();
  });

  it('rejects login with wrong password', async () => {
    const res = await request(app).post('/api/auth/login').send({
      email: 'user@test.com',
      password: 'wrongpassword'
    });
    expect(res.statusCode).toBe(401);
  });

  it('rejects unauthenticated access to /me', async () => {
    const res = await request(app).get('/api/auth/me');
    expect(res.statusCode).toBe(401);
  });

  it('returns current user with valid token', async () => {
    const res = await request(app).get('/api/auth/me').set('Authorization', `Bearer ${userToken}`);
    expect(res.statusCode).toBe(200);
    expect(res.body.user.email).toBe('user@test.com');
  });
});

describe('Recipes module', () => {
  it('lists seeded recipes', async () => {
    const res = await request(app).get('/api/recipes').set('Authorization', `Bearer ${userToken}`);
    expect(res.statusCode).toBe(200);
    expect(res.body.recipes.length).toBeGreaterThan(0);
    recipeId = res.body.recipes[0].id;
  });

  it('blocks non-admin from creating a recipe', async () => {
    const res = await request(app)
      .post('/api/recipes')
      .set('Authorization', `Bearer ${userToken}`)
      .send({ title: 'Test Recipe', category: 'Test' });
    expect(res.statusCode).toBe(403);
  });

  it('allows admin to create a recipe', async () => {
    const res = await request(app)
      .post('/api/recipes')
      .set('Authorization', `Bearer ${adminToken}`)
      .send({ title: 'Admin Recipe', category: 'Test', calories: 100, ingredients: ['test'], steps: ['test'], tags: ['test'] });
    expect(res.statusCode).toBe(201);
    expect(res.body.recipe.title).toBe('Admin Recipe');
  });

  it('logs a recipe as eaten and feeds analytics', async () => {
    const res = await request(app)
      .post(`/api/recipes/${recipeId}/log`)
      .set('Authorization', `Bearer ${userToken}`)
      .send({});
    expect(res.statusCode).toBe(201);
  });
});

describe('Grocery list module', () => {
  it('adds an item to the grocery list', async () => {
    const res = await request(app)
      .post('/api/grocery/items')
      .set('Authorization', `Bearer ${userToken}`)
      .send({ name: 'Bananas', quantity: '6', category: 'Produce' });
    expect(res.statusCode).toBe(201);
    expect(res.body.item.name).toBe('Bananas');
  });

  it('retrieves the grocery list', async () => {
    const res = await request(app).get('/api/grocery').set('Authorization', `Bearer ${userToken}`);
    expect(res.statusCode).toBe(200);
    expect(res.body.list.items.length).toBeGreaterThan(0);
  });

  it('adds ingredients from a recipe', async () => {
    const res = await request(app)
      .post(`/api/grocery/from-recipe/${recipeId}`)
      .set('Authorization', `Bearer ${userToken}`);
    expect(res.statusCode).toBe(201);
    expect(res.body.items.length).toBeGreaterThan(0);
  });
});

describe('Nutrition tips module', () => {
  it('lists seeded tips', async () => {
    const res = await request(app).get('/api/tips').set('Authorization', `Bearer ${userToken}`);
    expect(res.statusCode).toBe(200);
    expect(res.body.tips.length).toBeGreaterThan(0);
  });

  it('gets a random tip', async () => {
    const res = await request(app).get('/api/tips/random').set('Authorization', `Bearer ${userToken}`);
    expect(res.statusCode).toBe(200);
    expect(res.body.tip).toBeDefined();
  });
});

describe('Analytics module', () => {
  it('returns dashboard analytics', async () => {
    const res = await request(app).get('/api/analytics/dashboard').set('Authorization', `Bearer ${userToken}`);
    expect(res.statusCode).toBe(200);
    expect(res.body.today).toBeDefined();
    expect(res.body.weekly).toBeDefined();
    expect(res.body.monthly).toBeDefined();
  });

  it('returns weekly chart data', async () => {
    const res = await request(app).get('/api/analytics/weekly').set('Authorization', `Bearer ${userToken}`);
    expect(res.statusCode).toBe(200);
    expect(Array.isArray(res.body.data)).toBe(true);
  });
});

describe('Admin panel module', () => {
  it('blocks non-admin from listing users', async () => {
    const res = await request(app).get('/api/admin/users').set('Authorization', `Bearer ${userToken}`);
    expect(res.statusCode).toBe(403);
  });

  it('allows admin to list users', async () => {
    const res = await request(app).get('/api/admin/users').set('Authorization', `Bearer ${adminToken}`);
    expect(res.statusCode).toBe(200);
    expect(res.body.users.length).toBeGreaterThanOrEqual(2);
  });

  it('allows admin to view platform stats', async () => {
    const res = await request(app).get('/api/admin/stats').set('Authorization', `Bearer ${adminToken}`);
    expect(res.statusCode).toBe(200);
    expect(res.body.totalUsers).toBeGreaterThanOrEqual(2);
  });
});

describe('AI assistant module', () => {
  it('rejects chat without a message', async () => {
    const res = await request(app)
      .post('/api/assistant/chat')
      .set('Authorization', `Bearer ${userToken}`)
      .send({});
    expect(res.statusCode).toBe(400);
  });

  it('rejects chat when GEMINI_API_KEY is not configured', async () => {
    const res = await request(app)
      .post('/api/assistant/chat')
      .set('Authorization', `Bearer ${userToken}`)
      .send({ message: 'What should I eat for breakfast?' });
    // No real key configured in test env -> expect graceful 500, not a crash
    expect([500, 502, 200]).toContain(res.statusCode);
  });
});
