const { v4: uuidv4 } = require('uuid');
const db = require('./db');

function seed() {
  if (db.get('recipes').size().value() === 0) {
    const recipes = [
      {
        id: uuidv4(),
        title: 'Grilled Lemon Herb Chicken',
        category: 'High-Protein',
        calories: 320,
        protein: 38,
        carbs: 6,
        fat: 14,
        ingredients: ['2 chicken breasts', '1 lemon', '2 tbsp olive oil', 'garlic', 'rosemary', 'salt', 'pepper'],
        steps: [
          'Marinate chicken in lemon juice, olive oil, garlic and rosemary for 30 minutes.',
          'Preheat grill or pan to medium-high heat.',
          'Grill chicken 6-7 minutes per side until internal temp reaches 165F.',
          'Rest 5 minutes before slicing.'
        ],
        tags: ['gluten-free', 'high-protein', 'dinner']
      },
      {
        id: uuidv4(),
        title: 'Overnight Oats with Berries',
        category: 'Breakfast',
        calories: 290,
        protein: 12,
        carbs: 45,
        fat: 7,
        ingredients: ['1/2 cup rolled oats', '1/2 cup milk', '1/4 cup yogurt', '1 tbsp chia seeds', 'mixed berries', 'honey'],
        steps: [
          'Combine oats, milk, yogurt, and chia seeds in a jar.',
          'Stir well and refrigerate overnight.',
          'Top with berries and honey before serving.'
        ],
        tags: ['vegetarian', 'breakfast', 'meal-prep']
      },
      {
        id: uuidv4(),
        title: 'Quinoa Chickpea Buddha Bowl',
        category: 'Vegan',
        calories: 410,
        protein: 16,
        carbs: 58,
        fat: 13,
        ingredients: ['1 cup cooked quinoa', '1 cup chickpeas', 'spinach', 'avocado', 'cherry tomatoes', 'tahini dressing'],
        steps: [
          'Cook quinoa according to package instructions.',
          'Roast chickpeas with paprika and cumin for 20 minutes at 400F.',
          'Assemble bowl with quinoa, chickpeas, spinach, avocado and tomatoes.',
          'Drizzle with tahini dressing.'
        ],
        tags: ['vegan', 'gluten-free', 'lunch']
      },
      {
        id: uuidv4(),
        title: 'Baked Salmon with Asparagus',
        category: 'High-Protein',
        calories: 380,
        protein: 34,
        carbs: 8,
        fat: 22,
        ingredients: ['1 salmon fillet', '1 bunch asparagus', '1 tbsp olive oil', 'lemon slices', 'salt', 'pepper'],
        steps: [
          'Preheat oven to 400F.',
          'Place salmon and asparagus on a sheet pan, drizzle with olive oil.',
          'Top salmon with lemon slices, season with salt and pepper.',
          'Bake for 15-18 minutes until salmon flakes easily.'
        ],
        tags: ['keto', 'gluten-free', 'dinner']
      },
      {
        id: uuidv4(),
        title: 'Greek Yogurt Protein Smoothie',
        category: 'Snack',
        calories: 220,
        protein: 20,
        carbs: 28,
        fat: 4,
        ingredients: ['1 cup Greek yogurt', '1 banana', '1/2 cup spinach', '1 tbsp peanut butter', 'ice', 'milk'],
        steps: [
          'Add all ingredients to a blender.',
          'Blend until smooth, adding milk to reach desired consistency.',
          'Pour and serve immediately.'
        ],
        tags: ['vegetarian', 'high-protein', 'snack']
      }
    ];
    db.set('recipes', recipes).write();
  }

  if (db.get('tips').size().value() === 0) {
    const tips = [
      { id: uuidv4(), category: 'Hydration', title: 'Drink water before meals', content: 'Drinking a glass of water about 20-30 minutes before meals can help with portion control and digestion.' },
      { id: uuidv4(), category: 'Protein', title: 'Spread protein across meals', content: 'Aim to include a protein source in every meal rather than loading it all at dinner, to support muscle maintenance and satiety.' },
      { id: uuidv4(), category: 'Fiber', title: 'Prioritize whole foods', content: 'Whole grains, legumes, fruits, and vegetables provide fiber that supports digestion and helps you feel full longer.' },
      { id: uuidv4(), category: 'Sugar', title: 'Watch hidden sugars', content: 'Sauces, dressings, and flavored yogurts often contain added sugar. Check nutrition labels for "added sugars".' },
      { id: uuidv4(), category: 'Meal Prep', title: 'Batch cook proteins', content: 'Cooking a large batch of a lean protein once a week saves time and makes healthy meals easier to assemble.' },
      { id: uuidv4(), category: 'Mindful Eating', title: 'Slow down while eating', content: 'It takes about 20 minutes for your brain to register fullness, so eating slowly can help prevent overeating.' }
    ];
    db.set('tips', tips).write();
  }
}

module.exports = seed;
