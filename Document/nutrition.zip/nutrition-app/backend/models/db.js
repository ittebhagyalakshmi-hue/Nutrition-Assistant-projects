const low = require('lowdb');
const FileSync = require('lowdb/adapters/FileSync');
const path = require('path');
const fs = require('fs');

const dataDir = path.join(__dirname, '..', 'data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

const dbFile = process.env.NODE_ENV === 'test'
  ? path.join(dataDir, 'test-db.json')
  : path.join(dataDir, 'db.json');

const adapter = new FileSync(dbFile);
const db = low(adapter);

db.defaults({
  users: [],
  recipes: [],
  groceryLists: [],
  tips: [],
  chatLogs: [],
  nutritionLogs: []
}).write();

module.exports = db;
