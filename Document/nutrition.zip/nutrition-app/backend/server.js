require('dotenv').config();
const express = require('express');
const cors = require('cors');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');

const seed = require('./models/seed');
const { notFound, errorHandler } = require('./middleware/errorHandler');

const authRoutes = require('./routes/auth');
const assistantRoutes = require('./routes/assistant');
const recipeRoutes = require('./routes/recipes');
const groceryRoutes = require('./routes/grocery');
const tipRoutes = require('./routes/tips');
const analyticsRoutes = require('./routes/analytics');
const adminRoutes = require('./routes/admin');

seed();

const app = express();

app.use(cors({ origin: process.env.CORS_ORIGIN || '*' }));
app.use(express.json());
app.use(morgan(process.env.NODE_ENV === 'test' ? 'tiny' : 'dev'));

const limiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 300 });
app.use('/api/', limiter);

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

app.use('/api/auth', authRoutes);
app.use('/api/assistant', assistantRoutes);
app.use('/api/recipes', recipeRoutes);
app.use('/api/grocery', groceryRoutes);
app.use('/api/tips', tipRoutes);
app.use('/api/analytics', analyticsRoutes);
app.use('/api/admin', adminRoutes);

app.use(notFound);
app.use(errorHandler);

const PORT = process.env.PORT || 5000;

if (require.main === module) {
  app.listen(PORT, () => {
    console.log(`Nutrition Assistant API running on port ${PORT}`);
  });
}

module.exports = app;
