const express = require('express');
const { v4: uuidv4 } = require('uuid');
const fetch = require('node-fetch');
const db = require('../models/db');
const { authRequired } = require('../middleware/auth');

const router = express.Router();

const SYSTEM_CONTEXT = `You are a helpful, encouraging AI nutrition assistant inside a nutrition tracking app.
Give practical, evidence-based nutrition and healthy-eating guidance. Keep answers concise and actionable.
You are not a doctor: for medical concerns (e.g. diagnosed conditions, medications, eating disorders), advise the user to consult a licensed professional instead of giving specific clinical advice.`;

async function callGemini(message, history) {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'your_gemini_api_key_here') {
    const err = new Error('GEMINI_API_KEY is not configured on the server. Add it to backend/.env');
    err.status = 500;
    throw err;
  }

  const model = process.env.GEMINI_MODEL || 'gemini-1.5-flash';
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${apiKey}`;

  const contents = [
    { role: 'user', parts: [{ text: SYSTEM_CONTEXT }] },
    { role: 'model', parts: [{ text: 'Understood. I will act as a nutrition assistant.' }] },
    ...history.map(h => ({
      role: h.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: h.content }]
    })),
    { role: 'user', parts: [{ text: message }] }
  ];

  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      contents,
      generationConfig: { temperature: 0.7, maxOutputTokens: 500 }
    })
  });

  if (!response.ok) {
    const errText = await response.text();
    const err = new Error(`Gemini API error: ${response.status} ${errText}`);
    err.status = 502;
    throw err;
  }

  const data = await response.json();
  const text = data?.candidates?.[0]?.content?.parts?.map(p => p.text).join('') || '';
  if (!text) {
    const err = new Error('Gemini API returned no content. The response may have been blocked by safety filters.');
    err.status = 502;
    throw err;
  }
  return text;
}

// POST /api/assistant/chat
router.post('/chat', authRequired, async (req, res, next) => {
  try {
    const { message } = req.body;
    if (!message || !message.trim()) {
      return res.status(400).json({ error: 'Message is required.' });
    }

    const history = db.get('chatLogs')
      .filter({ userId: req.user.id })
      .takeRight(10)
      .value();

    const reply = await callGemini(message, history.flatMap(h => ([
      { role: 'user', content: h.message },
      { role: 'assistant', content: h.reply }
    ])));

    const log = {
      id: uuidv4(),
      userId: req.user.id,
      message,
      reply,
      createdAt: new Date().toISOString()
    };
    db.get('chatLogs').push(log).write();

    return res.json({ reply, id: log.id, createdAt: log.createdAt });
  } catch (err) {
    return next(err);
  }
});

// GET /api/assistant/history
router.get('/history', authRequired, (req, res) => {
  const history = db.get('chatLogs')
    .filter({ userId: req.user.id })
    .sortBy('createdAt')
    .takeRight(50)
    .value();
  return res.json({ history });
});

module.exports = router;
