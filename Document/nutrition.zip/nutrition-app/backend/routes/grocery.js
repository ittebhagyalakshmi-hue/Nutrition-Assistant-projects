const express = require('express');
const { v4: uuidv4 } = require('uuid');
const db = require('../models/db');
const { authRequired } = require('../middleware/auth');

const router = express.Router();

function getOrCreateList(userId) {
  let list = db.get('groceryLists').find({ userId }).value();
  if (!list) {
    list = { id: uuidv4(), userId, items: [] };
    db.get('groceryLists').push(list).write();
  }
  return list;
}

// GET /api/grocery
router.get('/', authRequired, (req, res) => {
  const list = getOrCreateList(req.user.id);
  return res.json({ list });
});

// POST /api/grocery/items
router.post('/items', authRequired, (req, res) => {
  const { name, quantity, category } = req.body;
  if (!name) return res.status(400).json({ error: 'Item name is required.' });

  getOrCreateList(req.user.id);
  const listRef = db.get('groceryLists').find({ userId: req.user.id });
  const item = {
    id: uuidv4(),
    name,
    quantity: quantity || '1',
    category: category || 'General',
    checked: false
  };
  listRef.get('items').push(item).write();
  return res.status(201).json({ item });
});

// PUT /api/grocery/items/:itemId  (toggle checked / edit)
router.put('/items/:itemId', authRequired, (req, res) => {
  const listRef = db.get('groceryLists').find({ userId: req.user.id });
  if (!listRef.value()) return res.status(404).json({ error: 'Grocery list not found.' });

  const itemRef = listRef.get('items').find({ id: req.params.itemId });
  if (!itemRef.value()) return res.status(404).json({ error: 'Item not found.' });

  itemRef.assign(req.body).write();
  return res.json({ item: itemRef.value() });
});

// DELETE /api/grocery/items/:itemId
router.delete('/items/:itemId', authRequired, (req, res) => {
  const listRef = db.get('groceryLists').find({ userId: req.user.id });
  if (!listRef.value()) return res.status(404).json({ error: 'Grocery list not found.' });

  listRef.get('items').remove({ id: req.params.itemId }).write();
  return res.json({ success: true });
});

// POST /api/grocery/from-recipe/:recipeId  (auto-add ingredients from a recipe)
router.post('/from-recipe/:recipeId', authRequired, (req, res) => {
  const recipe = db.get('recipes').find({ id: req.params.recipeId }).value();
  if (!recipe) return res.status(404).json({ error: 'Recipe not found.' });

  getOrCreateList(req.user.id);
  const listRef = db.get('groceryLists').find({ userId: req.user.id });

  const newItems = recipe.ingredients.map(ing => ({
    id: uuidv4(),
    name: ing,
    quantity: '1',
    category: recipe.category,
    checked: false
  }));

  newItems.forEach(item => listRef.get('items').push(item).write());
  return res.status(201).json({ items: newItems });
});

// DELETE /api/grocery/clear
router.delete('/clear', authRequired, (req, res) => {
  const listRef = db.get('groceryLists').find({ userId: req.user.id });
  if (!listRef.value()) return res.status(404).json({ error: 'Grocery list not found.' });
  listRef.assign({ items: [] }).write();
  return res.json({ success: true });
});

module.exports = router;
