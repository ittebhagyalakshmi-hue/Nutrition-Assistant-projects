const express = require('express');
const { v4: uuidv4 } = require('uuid');
const db = require('../models/db');
const { authRequired, adminRequired } = require('../middleware/auth');

const router = express.Router();

// GET /api/recipes  (supports ?category= & ?search=)
router.get('/', authRequired, (req, res) => {
  const { category, search } = req.query;
  let recipes = db.get('recipes').value();

  if (category) {
    recipes = recipes.filter(r => r.category.toLowerCase() === String(category).toLowerCase());
  }
  if (search) {
    const q = String(search).toLowerCase();
    recipes = recipes.filter(r =>
      r.title.toLowerCase().includes(q) ||
      r.tags.some(t => t.toLowerCase().includes(q))
    );
  }
  return res.json({ recipes });
});

// GET /api/recipes/:id
router.get('/:id', authRequired, (req, res) => {
  const recipe = db.get('recipes').find({ id: req.params.id }).value();
  if (!recipe) return res.status(404).json({ error: 'Recipe not found.' });
  return res.json({ recipe });
});

// POST /api/recipes  (admin only)
router.post('/', authRequired, adminRequired, (req, res) => {
  const { title, category, calories, protein, carbs, fat, ingredients, steps, tags } = req.body;
  if (!title || !category) {
    return res.status(400).json({ error: 'Title and category are required.' });
  }
  const recipe = {
    id: uuidv4(),
    title,
    category,
    calories: Number(calories) || 0,
    protein: Number(protein) || 0,
    carbs: Number(carbs) || 0,
    fat: Number(fat) || 0,
    ingredients: Array.isArray(ingredients) ? ingredients : [],
    steps: Array.isArray(steps) ? steps : [],
    tags: Array.isArray(tags) ? tags : []
  };
  db.get('recipes').push(recipe).write();
  return res.status(201).json({ recipe });
});

// PUT /api/recipes/:id  (admin only)
router.put('/:id', authRequired, adminRequired, (req, res) => {
  const recipeRef = db.get('recipes').find({ id: req.params.id });
  if (!recipeRef.value()) return res.status(404).json({ error: 'Recipe not found.' });
  recipeRef.assign(req.body).write();
  return res.json({ recipe: recipeRef.value() });
});

// DELETE /api/recipes/:id  (admin only)
router.delete('/:id', authRequired, adminRequired, (req, res) => {
  const exists = db.get('recipes').find({ id: req.params.id }).value();
  if (!exists) return res.status(404).json({ error: 'Recipe not found.' });
  db.get('recipes').remove({ id: req.params.id }).write();
  return res.json({ success: true });
});

// POST /api/recipes/:id/log  (log that user ate this recipe - feeds analytics)
router.post('/:id/log', authRequired, (req, res) => {
  const recipe = db.get('recipes').find({ id: req.params.id }).value();
  if (!recipe) return res.status(404).json({ error: 'Recipe not found.' });

  const entry = {
    id: uuidv4(),
    userId: req.user.id,
    recipeId: recipe.id,
    title: recipe.title,
    calories: recipe.calories,
    protein: recipe.protein,
    carbs: recipe.carbs,
    fat: recipe.fat,
    date: (req.body.date || new Date().toISOString()).slice(0, 10)
  };
  db.get('nutritionLogs').push(entry).write();
  return res.status(201).json({ entry });
});

module.exports = router;
