const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const db = require('../models/db');
const { authRequired } = require('../middleware/auth');

const router = express.Router();

function signToken(user) {
  return jwt.sign(
    { id: user.id, email: user.email, role: user.role, name: user.name },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || '7d' }
  );
}

function publicUser(user) {
  const { password, ...rest } = user;
  return rest;
}

// POST /api/auth/register
router.post('/register', async (req, res, next) => {
  try {
    const { name, email, password, adminCode } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ error: 'Name, email and password are required.' });
    }
    if (password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters.' });
    }

    const existing = db.get('users').find({ email: email.toLowerCase() }).value();
    if (existing) {
      return res.status(409).json({ error: 'An account with this email already exists.' });
    }

    let role = 'user';
    if (adminCode && process.env.ADMIN_SIGNUP_CODE && adminCode === process.env.ADMIN_SIGNUP_CODE) {
      role = 'admin';
    }

    const hashed = await bcrypt.hash(password, 10);
    const user = {
      id: uuidv4(),
      name,
      email: email.toLowerCase(),
      password: hashed,
      role,
      createdAt: new Date().toISOString(),
      profile: { goal: 'maintain', dailyCalorieTarget: 2000 }
    };

    db.get('users').push(user).write();

    const token = signToken(user);
    return res.status(201).json({ token, user: publicUser(user) });
  } catch (err) {
    return next(err);
  }
});

// POST /api/auth/login
router.post('/login', async (req, res, next) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required.' });
    }

    const user = db.get('users').find({ email: email.toLowerCase() }).value();
    if (!user) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    const match = await bcrypt.compare(password, user.password);
    if (!match) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    const token = signToken(user);
    return res.json({ token, user: publicUser(user) });
  } catch (err) {
    return next(err);
  }
});

// GET /api/auth/me
router.get('/me', authRequired, (req, res) => {
  const user = db.get('users').find({ id: req.user.id }).value();
  if (!user) return res.status(404).json({ error: 'User not found.' });
  return res.json({ user: publicUser(user) });
});

// PUT /api/auth/profile
router.put('/profile', authRequired, (req, res) => {
  const { goal, dailyCalorieTarget } = req.body;
  const user = db.get('users').find({ id: req.user.id });
  if (!user.value()) return res.status(404).json({ error: 'User not found.' });

  user.assign({
    profile: {
      goal: goal || user.value().profile?.goal || 'maintain',
      dailyCalorieTarget: dailyCalorieTarget || user.value().profile?.dailyCalorieTarget || 2000
    }
  }).write();

  return res.json({ user: publicUser(user.value()) });
});

module.exports = router;
