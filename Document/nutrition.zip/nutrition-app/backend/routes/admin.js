const express = require('express');
const db = require('../models/db');
const { authRequired, adminRequired } = require('../middleware/auth');

const router = express.Router();

router.use(authRequired, adminRequired);

function publicUser(user) {
  const { password, ...rest } = user;
  return rest;
}

// GET /api/admin/users
router.get('/users', (req, res) => {
  const users = db.get('users').value().map(publicUser);
  return res.json({ users });
});

// PUT /api/admin/users/:id/role
router.put('/users/:id/role', (req, res) => {
  const { role } = req.body;
  if (!['user', 'admin'].includes(role)) {
    return res.status(400).json({ error: "Role must be 'user' or 'admin'." });
  }
  const userRef = db.get('users').find({ id: req.params.id });
  if (!userRef.value()) return res.status(404).json({ error: 'User not found.' });
  userRef.assign({ role }).write();
  return res.json({ user: publicUser(userRef.value()) });
});

// DELETE /api/admin/users/:id
router.delete('/users/:id', (req, res) => {
  const exists = db.get('users').find({ id: req.params.id }).value();
  if (!exists) return res.status(404).json({ error: 'User not found.' });
  db.get('users').remove({ id: req.params.id }).write();
  return res.json({ success: true });
});

// GET /api/admin/stats  (platform-wide analytics)
router.get('/stats', (req, res) => {
  const users = db.get('users').value();
  const recipes = db.get('recipes').value();
  const tips = db.get('tips').value();
  const logs = db.get('nutritionLogs').value();
  const chats = db.get('chatLogs').value();

  const recipePopularity = {};
  logs.forEach(l => {
    recipePopularity[l.title] = (recipePopularity[l.title] || 0) + 1;
  });
  const topRecipes = Object.entries(recipePopularity)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([title, count]) => ({ title, count }));

  return res.json({
    totalUsers: users.length,
    totalAdmins: users.filter(u => u.role === 'admin').length,
    totalRecipes: recipes.length,
    totalTips: tips.length,
    totalNutritionLogs: logs.length,
    totalAssistantChats: chats.length,
    topRecipes
  });
});

module.exports = router;
