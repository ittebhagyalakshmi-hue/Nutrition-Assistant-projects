const express = require('express');
const { v4: uuidv4 } = require('uuid');
const db = require('../models/db');
const { authRequired, adminRequired } = require('../middleware/auth');

const router = express.Router();

// GET /api/tips
router.get('/', authRequired, (req, res) => {
  const { category } = req.query;
  let tips = db.get('tips').value();
  if (category) {
    tips = tips.filter(t => t.category.toLowerCase() === String(category).toLowerCase());
  }
  return res.json({ tips });
});

// GET /api/tips/random
router.get('/random', authRequired, (req, res) => {
  const tips = db.get('tips').value();
  if (!tips.length) return res.status(404).json({ error: 'No tips available.' });
  const tip = tips[Math.floor(Math.random() * tips.length)];
  return res.json({ tip });
});

// POST /api/tips (admin only)
router.post('/', authRequired, adminRequired, (req, res) => {
  const { category, title, content } = req.body;
  if (!category || !title || !content) {
    return res.status(400).json({ error: 'Category, title and content are required.' });
  }
  const tip = { id: uuidv4(), category, title, content };
  db.get('tips').push(tip).write();
  return res.status(201).json({ tip });
});

// PUT /api/tips/:id (admin only)
router.put('/:id', authRequired, adminRequired, (req, res) => {
  const tipRef = db.get('tips').find({ id: req.params.id });
  if (!tipRef.value()) return res.status(404).json({ error: 'Tip not found.' });
  tipRef.assign(req.body).write();
  return res.json({ tip: tipRef.value() });
});

// DELETE /api/tips/:id (admin only)
router.delete('/:id', authRequired, adminRequired, (req, res) => {
  const exists = db.get('tips').find({ id: req.params.id }).value();
  if (!exists) return res.status(404).json({ error: 'Tip not found.' });
  db.get('tips').remove({ id: req.params.id }).write();
  return res.json({ success: true });
});

module.exports = router;
