const express = require('express');
const db = require('../models/db');
const { authRequired } = require('../middleware/auth');

const router = express.Router();

function dateNDaysAgo(n) {
  const d = new Date();
  d.setDate(d.getDate() - n);
  return d.toISOString().slice(0, 10);
}

function aggregateByDate(logs) {
  const map = {};
  logs.forEach(l => {
    if (!map[l.date]) map[l.date] = { date: l.date, calories: 0, protein: 0, carbs: 0, fat: 0, meals: 0 };
    map[l.date].calories += l.calories;
    map[l.date].protein += l.protein;
    map[l.date].carbs += l.carbs;
    map[l.date].fat += l.fat;
    map[l.date].meals += 1;
  });
  return Object.values(map).sort((a, b) => (a.date > b.date ? 1 : -1));
}

// GET /api/analytics/weekly
router.get('/weekly', authRequired, (req, res) => {
  const since = dateNDaysAgo(7);
  const logs = db.get('nutritionLogs')
    .filter(l => l.userId === req.user.id && l.date >= since)
    .value();
  return res.json({ range: 'weekly', data: aggregateByDate(logs) });
});

// GET /api/analytics/monthly
router.get('/monthly', authRequired, (req, res) => {
  const since = dateNDaysAgo(30);
  const logs = db.get('nutritionLogs')
    .filter(l => l.userId === req.user.id && l.date >= since)
    .value();
  return res.json({ range: 'monthly', data: aggregateByDate(logs) });
});

// GET /api/analytics/dashboard
router.get('/dashboard', authRequired, (req, res) => {
  const user = db.get('users').find({ id: req.user.id }).value();
  const since7 = dateNDaysAgo(7);
  const since30 = dateNDaysAgo(30);

  const allLogs = db.get('nutritionLogs').filter({ userId: req.user.id }).value();
  const weekLogs = allLogs.filter(l => l.date >= since7);
  const monthLogs = allLogs.filter(l => l.date >= since30);

  const sum = (arr, key) => arr.reduce((acc, l) => acc + l[key], 0);
  const avg = (arr, key) => (arr.length ? Math.round(sum(arr, key) / arr.length) : 0);

  const todayStr = new Date().toISOString().slice(0, 10);
  const todayLogs = allLogs.filter(l => l.date === todayStr);

  const groceryList = db.get('groceryLists').find({ userId: req.user.id }).value();
  const groceryPending = groceryList ? groceryList.items.filter(i => !i.checked).length : 0;

  const chatCount = db.get('chatLogs').filter({ userId: req.user.id }).size().value();

  return res.json({
    profile: user?.profile || { goal: 'maintain', dailyCalorieTarget: 2000 },
    today: {
      calories: sum(todayLogs, 'calories'),
      protein: sum(todayLogs, 'protein'),
      carbs: sum(todayLogs, 'carbs'),
      fat: sum(todayLogs, 'fat'),
      mealsLogged: todayLogs.length
    },
    weekly: {
      avgCalories: avg(weekLogs, 'calories'),
      totalMeals: weekLogs.length,
      chart: aggregateByDate(weekLogs)
    },
    monthly: {
      avgCalories: avg(monthLogs, 'calories'),
      totalMeals: monthLogs.length,
      chart: aggregateByDate(monthLogs)
    },
    groceryPending,
    assistantConversations: chatCount
  });
});

module.exports = router;
