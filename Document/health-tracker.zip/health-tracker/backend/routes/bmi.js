const express = require('express');
const BmiRecord = require('../models/BmiRecord');
const auth = require('../middleware/auth');
const { calcBmi, bmiCategory } = require('../utils/helpers');

const router = express.Router();

// POST /api/bmi -> calculate and save a BMI record
router.post('/', auth, async (req, res) => {
  try {
    const { heightCm, weightKg } = req.body;
    if (!heightCm || !weightKg) {
      return res.status(400).json({ message: 'heightCm and weightKg are required' });
    }
    const bmi = calcBmi(weightKg, heightCm);
    const category = bmiCategory(bmi);

    const record = await BmiRecord.create({
      user: req.userId,
      heightCm,
      weightKg,
      bmi,
      category,
    });

    res.status(201).json(record);
  } catch (err) {
    res.status(500).json({ message: 'BMI calculation failed', error: err.message });
  }
});

// GET /api/bmi/history
router.get('/history', auth, async (req, res) => {
  const records = await BmiRecord.find({ user: req.userId }).sort({ recordedAt: -1 }).limit(50);
  res.json(records);
});

module.exports = router;
