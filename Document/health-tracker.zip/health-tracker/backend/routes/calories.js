const express = require('express');
const CalorieLog = require('../models/CalorieLog');
const FoodItem = require('../models/FoodItem');
const User = require('../models/User');
const auth = require('../middleware/auth');
const { todayStr } = require('../utils/helpers');

const router = express.Router();

// GET /api/calories?date=YYYY-MM-DD
router.get('/', auth, async (req, res) => {
  const date = req.query.date || todayStr();
  let log = await CalorieLog.findOne({ user: req.userId, date }).populate('entries.foodItem');
  if (!log) {
    const user = await User.findById(req.userId);
    log = { user: req.userId, date, entries: [], calorieGoal: user?.dailyCalorieGoal || 2000 };
  }
  const totalCalories = log.entries.reduce((sum, e) => sum + e.calories, 0);
  res.json({ ...(log.toObject ? log.toObject() : log), totalCalories });
});

// POST /api/calories -> log a food entry
router.post('/', auth, async (req, res) => {
  try {
    const { foodItemId, servings = 1, mealType, date } = req.body;
    if (!foodItemId || !mealType) {
      return res.status(400).json({ message: 'foodItemId and mealType are required' });
    }
    const foodItem = await FoodItem.findById(foodItemId);
    if (!foodItem) return res.status(404).json({ message: 'Food item not found' });

    const logDate = date || todayStr();
    const calories = Math.round(foodItem.caloriesPerServing * servings);

    let log = await CalorieLog.findOne({ user: req.userId, date: logDate });
    if (!log) {
      const user = await User.findById(req.userId);
      log = await CalorieLog.create({
        user: req.userId,
        date: logDate,
        entries: [],
        calorieGoal: user?.dailyCalorieGoal || 2000,
      });
    }

    log.entries.push({ foodItem: foodItemId, servings, mealType, calories });
    await log.save();
    await log.populate('entries.foodItem');

    res.status(201).json(log);
  } catch (err) {
    res.status(500).json({ message: 'Could not log food', error: err.message });
  }
});

// DELETE /api/calories/:logId/entries/:entryId
router.delete('/:logId/entries/:entryId', auth, async (req, res) => {
  const log = await CalorieLog.findOne({ _id: req.params.logId, user: req.userId });
  if (!log) return res.status(404).json({ message: 'Log not found' });

  log.entries = log.entries.filter((e) => e._id.toString() !== req.params.entryId);
  await log.save();
  res.json({ message: 'Entry removed', log });
});

// GET /api/calories/history?days=7
router.get('/history', auth, async (req, res) => {
  const days = Number(req.query.days) || 7;
  const logs = await CalorieLog.find({ user: req.userId }).sort({ date: -1 }).limit(days);
  const summary = logs
    .map((l) => ({
      date: l.date,
      totalCalories: l.entries.reduce((sum, e) => sum + e.calories, 0),
      calorieGoal: l.calorieGoal,
    }))
    .reverse();
  res.json(summary);
});

module.exports = router;
