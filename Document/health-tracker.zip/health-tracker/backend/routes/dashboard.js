const express = require('express');
const User = require('../models/User');
const CalorieLog = require('../models/CalorieLog');
const WaterIntake = require('../models/WaterIntake');
const Exercise = require('../models/Exercise');
const BmiRecord = require('../models/BmiRecord');
const auth = require('../middleware/auth');
const { todayStr, calcBmi, bmiCategory } = require('../utils/helpers');

const router = express.Router();

// GET /api/dashboard -> single-call summary for today, powers the User Dashboard
router.get('/', auth, async (req, res) => {
  try {
    const date = req.query.date || todayStr();
    const user = await User.findById(req.userId);
    if (!user) return res.status(404).json({ message: 'User not found' });

    const [calorieLog, waterLog, exercises, lastBmi] = await Promise.all([
      CalorieLog.findOne({ user: req.userId, date }),
      WaterIntake.findOne({ user: req.userId, date }),
      Exercise.find({ user: req.userId, date }),
      BmiRecord.findOne({ user: req.userId }).sort({ recordedAt: -1 }),
    ]);

    const caloriesConsumed = calorieLog
      ? calorieLog.entries.reduce((sum, e) => sum + e.calories, 0)
      : 0;
    const caloriesBurned = exercises.reduce((sum, e) => sum + e.caloriesBurned, 0);
    const waterMl = waterLog ? waterLog.entries.reduce((sum, e) => sum + e.amountMl, 0) : 0;

    let currentBmi = lastBmi;
    if (!currentBmi && user.heightCm && user.weightKg) {
      const bmi = calcBmi(user.weightKg, user.heightCm);
      currentBmi = { bmi, category: bmiCategory(bmi) };
    }

    res.json({
      date,
      user: { name: user.name, goal: user.goal },
      calories: {
        consumed: caloriesConsumed,
        burned: caloriesBurned,
        goal: user.dailyCalorieGoal,
        net: caloriesConsumed - caloriesBurned,
      },
      water: { consumedMl: waterMl, goalMl: user.dailyWaterGoalMl },
      exercise: {
        sessionCount: exercises.length,
        totalMinutes: exercises.reduce((sum, e) => sum + e.durationMin, 0),
        caloriesBurned,
      },
      bmi: currentBmi ? { value: currentBmi.bmi, category: currentBmi.category } : null,
    });
  } catch (err) {
    res.status(500).json({ message: 'Could not load dashboard', error: err.message });
  }
});

module.exports = router;
