const express = require('express');
const WaterIntake = require('../models/WaterIntake');
const User = require('../models/User');
const auth = require('../middleware/auth');
const { todayStr } = require('../utils/helpers');

const router = express.Router();

// GET /api/water?date=YYYY-MM-DD
router.get('/', auth, async (req, res) => {
  const date = req.query.date || todayStr();
  let log = await WaterIntake.findOne({ user: req.userId, date });
  if (!log) {
    const user = await User.findById(req.userId);
    log = { user: req.userId, date, entries: [], goalMl: user?.dailyWaterGoalMl || 2500 };
  }
  const totalMl = log.entries.reduce((sum, e) => sum + e.amountMl, 0);
  res.json({ ...(log.toObject ? log.toObject() : log), totalMl });
});

// POST /api/water -> log water intake
router.post('/', auth, async (req, res) => {
  try {
    const { amountMl, date } = req.body;
    if (!amountMl || amountMl <= 0) {
      return res.status(400).json({ message: 'amountMl must be a positive number' });
    }
    const logDate = date || todayStr();

    let log = await WaterIntake.findOne({ user: req.userId, date: logDate });
    if (!log) {
      const user = await User.findById(req.userId);
      log = await WaterIntake.create({
        user: req.userId,
        date: logDate,
        entries: [],
        goalMl: user?.dailyWaterGoalMl || 2500,
      });
    }

    log.entries.push({ amountMl });
    await log.save();
    const totalMl = log.entries.reduce((sum, e) => sum + e.amountMl, 0);
    res.status(201).json({ ...log.toObject(), totalMl });
  } catch (err) {
    res.status(500).json({ message: 'Could not log water intake', error: err.message });
  }
});

// DELETE /api/water/:logId/entries/:entryId
router.delete('/:logId/entries/:entryId', auth, async (req, res) => {
  const log = await WaterIntake.findOne({ _id: req.params.logId, user: req.userId });
  if (!log) return res.status(404).json({ message: 'Log not found' });

  log.entries = log.entries.filter((e) => e._id.toString() !== req.params.entryId);
  await log.save();
  const totalMl = log.entries.reduce((sum, e) => sum + e.amountMl, 0);
  res.json({ ...log.toObject(), totalMl });
});

// GET /api/water/history?days=7
router.get('/history', auth, async (req, res) => {
  const days = Number(req.query.days) || 7;
  const logs = await WaterIntake.find({ user: req.userId }).sort({ date: -1 }).limit(days);
  const summary = logs
    .map((l) => ({
      date: l.date,
      totalMl: l.entries.reduce((sum, e) => sum + e.amountMl, 0),
      goalMl: l.goalMl,
    }))
    .reverse();
  res.json(summary);
});

module.exports = router;
