const express = require('express');
const User = require('../models/User');
const auth = require('../middleware/auth');
const { calcTdee } = require('../utils/helpers');

const router = express.Router();

// GET /api/profile
router.get('/', auth, async (req, res) => {
  const user = await User.findById(req.userId);
  if (!user) return res.status(404).json({ message: 'User not found' });
  res.json(user);
});

// PUT /api/profile
router.put('/', auth, async (req, res) => {
  try {
    const allowed = [
      'name', 'age', 'gender', 'heightCm', 'weightKg',
      'activityLevel', 'goal', 'dailyCalorieGoal', 'dailyWaterGoalMl', 'avatarUrl',
    ];
    const updates = {};
    allowed.forEach((key) => {
      if (req.body[key] !== undefined) updates[key] = req.body[key];
    });

    const user = await User.findByIdAndUpdate(req.userId, updates, {
      new: true,
      runValidators: true,
    });
    if (!user) return res.status(404).json({ message: 'User not found' });
    res.json(user);
  } catch (err) {
    res.status(400).json({ message: 'Update failed', error: err.message });
  }
});

// GET /api/profile/tdee -> suggested daily calories based on profile
router.get('/tdee', auth, async (req, res) => {
  const user = await User.findById(req.userId);
  if (!user) return res.status(404).json({ message: 'User not found' });
  if (!user.weightKg || !user.heightCm || !user.age) {
    return res.status(400).json({ message: 'Complete your profile (age, height, weight) first' });
  }
  const tdee = calcTdee(user);
  const goalAdjustment = { lose_weight: -500, maintain: 0, gain_muscle: 300 }[user.goal] || 0;
  res.json({ tdee, recommendedCalories: tdee + goalAdjustment });
});

module.exports = router;
