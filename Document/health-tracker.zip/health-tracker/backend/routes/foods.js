const express = require('express');
const FoodItem = require('../models/FoodItem');
const auth = require('../middleware/auth');

const router = express.Router();

// GET /api/foods?search=&category=&page=&limit=
router.get('/', auth, async (req, res) => {
  const { search = '', category, page = 1, limit = 20 } = req.query;
  const query = {};
  if (search) query.$text = { $search: search };
  if (category) query.category = category;

  const skip = (Number(page) - 1) * Number(limit);
  const [items, total] = await Promise.all([
    FoodItem.find(query).skip(skip).limit(Number(limit)).sort({ name: 1 }),
    FoodItem.countDocuments(query),
  ]);

  res.json({ items, total, page: Number(page), pages: Math.ceil(total / Number(limit)) });
});

// GET /api/foods/:id
router.get('/:id', auth, async (req, res) => {
  const item = await FoodItem.findById(req.params.id);
  if (!item) return res.status(404).json({ message: 'Food item not found' });
  res.json(item);
});

// POST /api/foods -> add a custom food item
router.post('/', auth, async (req, res) => {
  try {
    const item = await FoodItem.create({ ...req.body, createdBy: req.userId });
    res.status(201).json(item);
  } catch (err) {
    res.status(400).json({ message: 'Could not create food item', error: err.message });
  }
});

// PUT /api/foods/:id
router.put('/:id', auth, async (req, res) => {
  try {
    const item = await FoodItem.findOneAndUpdate(
      { _id: req.params.id, createdBy: req.userId },
      req.body,
      { new: true, runValidators: true }
    );
    if (!item) return res.status(404).json({ message: 'Food item not found or not editable' });
    res.json(item);
  } catch (err) {
    res.status(400).json({ message: 'Update failed', error: err.message });
  }
});

// DELETE /api/foods/:id
router.delete('/:id', auth, async (req, res) => {
  const item = await FoodItem.findOneAndDelete({ _id: req.params.id, createdBy: req.userId });
  if (!item) return res.status(404).json({ message: 'Food item not found or not deletable' });
  res.json({ message: 'Food item deleted' });
});

module.exports = router;
