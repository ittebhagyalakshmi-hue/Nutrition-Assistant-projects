const express = require('express');
const Exercise = require('../models/Exercise');
const auth = require('../middleware/auth');
const { todayStr } = require('../utils/helpers');

const router = express.Router();

// GET /api/exercise?date=YYYY-MM-DD
router.get('/', auth, async (req, res) => {
  const date = req.query.date || todayStr();
  const entries = await Exercise.find({ user: req.userId, date }).sort({ createdAt: -1 });
  const totalCaloriesBurned = entries.reduce((sum, e) => sum + e.caloriesBurned, 0);
  const totalMinutes = entries.reduce((sum, e) => sum + e.durationMin, 0);
  res.json({ date, entries, totalCaloriesBurned, totalMinutes });
});

// POST /api/exercise -> log a workout
router.post('/', auth, async (req, res) => {
  try {
    const { name, type, durationMin, caloriesBurned, intensity, date, notes } = req.body;
    if (!name || !durationMin) {
      return res.status(400).json({ message: 'name and durationMin are required' });
    }
    const entry = await Exercise.create({
      user: req.userId,
      name,
      type,
      durationMin,
      caloriesBurned: caloriesBurned || 0,
      intensity,
      date: date || todayStr(),
      notes,
    });
    res.status(201).json(entry);
  } catch (err) {
    res.status(500).json({ message: 'Could not log exercise', error: err.message });
  }
});

// DELETE /api/exercise/:id
router.delete('/:id', auth, async (req, res) => {
  const entry = await Exercise.findOneAndDelete({ _id: req.params.id, user: req.userId });
  if (!entry) return res.status(404).json({ message: 'Exercise entry not found' });
  res.json({ message: 'Exercise entry deleted' });
});

// GET /api/exercise/history?days=7
router.get('/history', auth, async (req, res) => {
  const days = Number(req.query.days) || 7;
  const since = new Date();
  since.setDate(since.getDate() - days);
  const entries = await Exercise.find({
    user: req.userId,
    date: { $gte: todayStr(since) },
  }).sort({ date: 1 });

  const byDate = {};
  entries.forEach((e) => {
    byDate[e.date] = (byDate[e.date] || 0) + e.caloriesBurned;
  });
  res.json(Object.entries(byDate).map(([date, caloriesBurned]) => ({ date, caloriesBurned })));
});

module.exports = router;
