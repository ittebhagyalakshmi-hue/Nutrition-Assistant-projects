const express = require('express');
const MealPlan = require('../models/MealPlan');
const auth = require('../middleware/auth');
const { todayStr } = require('../utils/helpers');

const router = express.Router();

// GET /api/meal-plans?date=YYYY-MM-DD
router.get('/', auth, async (req, res) => {
  const date = req.query.date || todayStr();
  const plan = await MealPlan.findOne({ user: req.userId, date }).populate('meals.foodItem');
  res.json(plan || { user: req.userId, date, meals: [], notes: '' });
});

// GET /api/meal-plans/range?start=YYYY-MM-DD&end=YYYY-MM-DD
router.get('/range', auth, async (req, res) => {
  const { start, end } = req.query;
  if (!start || !end) return res.status(400).json({ message: 'start and end are required' });
  const plans = await MealPlan.find({
    user: req.userId,
    date: { $gte: start, $lte: end },
  })
    .populate('meals.foodItem')
    .sort({ date: 1 });
  res.json(plans);
});

// PUT /api/meal-plans -> upsert a day's plan (add/replace meals)
router.put('/', auth, async (req, res) => {
  try {
    const { date, meals, notes } = req.body;
    if (!date) return res.status(400).json({ message: 'date is required' });

    const plan = await MealPlan.findOneAndUpdate(
      { user: req.userId, date },
      { meals: meals || [], notes: notes || '' },
      { new: true, upsert: true, runValidators: true }
    ).populate('meals.foodItem');

    res.json(plan);
  } catch (err) {
    res.status(500).json({ message: 'Could not save meal plan', error: err.message });
  }
});

// POST /api/meal-plans/meal -> add a single meal to a day's plan
router.post('/meal', auth, async (req, res) => {
  try {
    const { date, foodItemId, servings = 1, mealType } = req.body;
    if (!date || !foodItemId || !mealType) {
      return res.status(400).json({ message: 'date, foodItemId and mealType are required' });
    }

    let plan = await MealPlan.findOne({ user: req.userId, date });
    if (!plan) plan = await MealPlan.create({ user: req.userId, date, meals: [] });

    plan.meals.push({ foodItem: foodItemId, servings, mealType });
    await plan.save();
    await plan.populate('meals.foodItem');

    res.status(201).json(plan);
  } catch (err) {
    res.status(500).json({ message: 'Could not add meal', error: err.message });
  }
});

// DELETE /api/meal-plans/:planId/meals/:mealId
router.delete('/:planId/meals/:mealId', auth, async (req, res) => {
  const plan = await MealPlan.findOne({ _id: req.params.planId, user: req.userId });
  if (!plan) return res.status(404).json({ message: 'Meal plan not found' });

  plan.meals = plan.meals.filter((m) => m._id.toString() !== req.params.mealId);
  await plan.save();
  res.json(plan);
});

module.exports = router;
