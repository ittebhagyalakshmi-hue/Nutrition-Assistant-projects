const mongoose = require('mongoose');

const FoodItemSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true, index: true },
    brand: { type: String, trim: true, default: '' },
    category: {
      type: String,
      enum: ['fruit', 'vegetable', 'grain', 'protein', 'dairy', 'fat', 'beverage', 'snack', 'other'],
      default: 'other',
    },
    servingSize: { type: Number, required: true, default: 100 },
    servingUnit: { type: String, required: true, default: 'g' },
    caloriesPerServing: { type: Number, required: true },
    macros: {
      proteinG: { type: Number, default: 0 },
      carbsG: { type: Number, default: 0 },
      fatG: { type: Number, default: 0 },
      fiberG: { type: Number, default: 0 },
      sugarG: { type: Number, default: 0 },
    },
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
    isVerified: { type: Boolean, default: false },
  },
  { timestamps: true }
);

FoodItemSchema.index({ name: 'text', brand: 'text' });

module.exports = mongoose.model('FoodItem', FoodItemSchema);
