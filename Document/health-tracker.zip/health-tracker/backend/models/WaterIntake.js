const mongoose = require('mongoose');

const WaterEntrySchema = new mongoose.Schema({
  amountMl: { type: Number, required: true, min: 1 },
  loggedAt: { type: Date, default: Date.now },
});

const WaterIntakeSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    date: { type: String, required: true, index: true }, // YYYY-MM-DD
    entries: [WaterEntrySchema],
    goalMl: { type: Number, default: 2500 },
  },
  { timestamps: true }
);

WaterIntakeSchema.index({ user: 1, date: 1 }, { unique: true });

module.exports = mongoose.model('WaterIntake', WaterIntakeSchema);
