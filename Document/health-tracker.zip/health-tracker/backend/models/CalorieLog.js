const mongoose = require('mongoose');

const CalorieLogEntrySchema = new mongoose.Schema({
  foodItem: { type: mongoose.Schema.Types.ObjectId, ref: 'FoodItem', required: true },
  servings: { type: Number, required: true, default: 1, min: 0.1 },
  mealType: {
    type: String,
    enum: ['breakfast', 'lunch', 'dinner', 'snack'],
    required: true,
  },
  calories: { type: Number, required: true },
  loggedAt: { type: Date, default: Date.now },
});

const CalorieLogSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    date: { type: String, required: true, index: true }, // YYYY-MM-DD
    entries: [CalorieLogEntrySchema],
    calorieGoal: { type: Number, default: 2000 },
  },
  { timestamps: true }
);

CalorieLogSchema.index({ user: 1, date: 1 }, { unique: true });

module.exports = mongoose.model('CalorieLog', CalorieLogSchema);
