const mongoose = require('mongoose');

const PlannedMealSchema = new mongoose.Schema({
  foodItem: { type: mongoose.Schema.Types.ObjectId, ref: 'FoodItem', required: true },
  servings: { type: Number, default: 1, min: 0.1 },
  mealType: {
    type: String,
    enum: ['breakfast', 'lunch', 'dinner', 'snack'],
    required: true,
  },
});

const MealPlanSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    date: { type: String, required: true, index: true }, // YYYY-MM-DD
    meals: [PlannedMealSchema],
    notes: { type: String, default: '' },
  },
  { timestamps: true }
);

MealPlanSchema.index({ user: 1, date: 1 }, { unique: true });

module.exports = mongoose.model('MealPlan', MealPlanSchema);
