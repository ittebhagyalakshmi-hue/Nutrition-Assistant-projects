const mongoose = require('mongoose');

const ExerciseEntrySchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    name: { type: String, required: true, trim: true },
    type: {
      type: String,
      enum: ['cardio', 'strength', 'flexibility', 'sports', 'other'],
      default: 'cardio',
    },
    durationMin: { type: Number, required: true, min: 1 },
    caloriesBurned: { type: Number, required: true, default: 0 },
    intensity: { type: String, enum: ['low', 'medium', 'high'], default: 'medium' },
    date: { type: String, required: true, index: true }, // YYYY-MM-DD
    notes: { type: String, default: '' },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Exercise', ExerciseEntrySchema);
