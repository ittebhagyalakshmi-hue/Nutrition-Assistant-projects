require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const authRoutes = require('./routes/auth');
const profileRoutes = require('./routes/profile');
const bmiRoutes = require('./routes/bmi');
const foodRoutes = require('./routes/foods');
const calorieRoutes = require('./routes/calories');
const waterRoutes = require('./routes/water');
const exerciseRoutes = require('./routes/exercise');
const mealPlannerRoutes = require('./routes/mealPlanner');
const dashboardRoutes = require('./routes/dashboard');

const app = express();

app.use(cors());
app.use(express.json());

app.use('/api/auth', authRoutes);
app.use('/api/profile', profileRoutes);
app.use('/api/bmi', bmiRoutes);
app.use('/api/foods', foodRoutes);
app.use('/api/calories', calorieRoutes);
app.use('/api/water', waterRoutes);
app.use('/api/exercise', exerciseRoutes);
app.use('/api/meal-plans', mealPlannerRoutes);
app.use('/api/dashboard', dashboardRoutes);

app.get('/api/health', (req, res) => res.json({ status: 'ok' }));

// Central error handler
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ message: 'Unexpected server error' });
});

const PORT = process.env.PORT || 5000;
const MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/health_tracker';

mongoose
  .connect(MONGO_URI)
  .then(() => {
    console.log('MongoDB connected');
    app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
  })
  .catch((err) => {
    console.error('MongoDB connection failed:', err.message);
    process.exit(1);
  });

module.exports = app;
