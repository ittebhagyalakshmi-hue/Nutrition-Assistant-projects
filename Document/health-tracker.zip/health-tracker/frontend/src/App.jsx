import React, { useEffect, useState } from 'react';
import { authApi, getToken, setToken } from './api/api';
import NavBar from './components/NavBar';
import AuthScreen from './components/AuthScreen';
import Dashboard from './components/Dashboard';
import Profile from './components/Profile';
import BMICalculator from './components/BMICalculator';
import MealPlanner from './components/MealPlanner';
import FoodDatabase from './components/FoodDatabase';
import CalorieTracker from './components/CalorieTracker';
import WaterTracker from './components/WaterTracker';
import ExerciseTracker from './components/ExerciseTracker';
import './styles/theme.css';

const SCREENS = {
  dashboard: Dashboard,
  profile: Profile,
  bmi: BMICalculator,
  meals: MealPlanner,
  foods: FoodDatabase,
  calories: CalorieTracker,
  water: WaterTracker,
  exercise: ExerciseTracker,
};

export default function App() {
  const [user, setUser] = useState(null);
  const [checking, setChecking] = useState(true);
  const [active, setActive] = useState('dashboard');

  useEffect(() => {
    if (!getToken()) { setChecking(false); return; }
    authApi
      .me()
      .then((u) => setUser(u))
      .catch(() => setToken(null))
      .finally(() => setChecking(false));
  }, []);

  const handleLogout = () => {
    setToken(null);
    setUser(null);
    setActive('dashboard');
  };

  if (checking) return <div className="ht-empty">Loading…</div>;
  if (!user) return <AuthScreen onAuthenticated={setUser} />;

  const Screen = SCREENS[active] || Dashboard;

  return (
    <div className="ht-app">
      <NavBar active={active} onNavigate={setActive} userName={user.name} onLogout={handleLogout} />
      <main className="ht-main">
        <Screen onNavigate={setActive} />
      </main>
    </div>
  );
}
