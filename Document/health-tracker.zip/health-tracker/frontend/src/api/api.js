const BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

function getToken() {
  return localStorage.getItem('ht_token');
}

async function request(path, { method = 'GET', body, auth = true } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (auth) {
    const token = getToken();
    if (token) headers.Authorization = `Bearer ${token}`;
  }

  const res = await fetch(`${BASE_URL}${path}`, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.message || `Request failed with status ${res.status}`);
  }
  return data;
}

// ---- Auth ----
export const authApi = {
  register: (payload) => request('/auth/register', { method: 'POST', body: payload, auth: false }),
  login: (payload) => request('/auth/login', { method: 'POST', body: payload, auth: false }),
  me: () => request('/auth/me'),
};

// ---- Profile ----
export const profileApi = {
  get: () => request('/profile'),
  update: (payload) => request('/profile', { method: 'PUT', body: payload }),
  tdee: () => request('/profile/tdee'),
};

// ---- Dashboard ----
export const dashboardApi = {
  get: (date) => request(`/dashboard${date ? `?date=${date}` : ''}`),
};

// ---- BMI ----
export const bmiApi = {
  calculate: (payload) => request('/bmi', { method: 'POST', body: payload }),
  history: () => request('/bmi/history'),
};

// ---- Foods ----
export const foodApi = {
  list: (params = {}) => {
    const qs = new URLSearchParams(params).toString();
    return request(`/foods${qs ? `?${qs}` : ''}`);
  },
  get: (id) => request(`/foods/${id}`),
  create: (payload) => request('/foods', { method: 'POST', body: payload }),
  update: (id, payload) => request(`/foods/${id}`, { method: 'PUT', body: payload }),
  remove: (id) => request(`/foods/${id}`, { method: 'DELETE' }),
};

// ---- Calorie Tracker ----
export const calorieApi = {
  get: (date) => request(`/calories${date ? `?date=${date}` : ''}`),
  log: (payload) => request('/calories', { method: 'POST', body: payload }),
  removeEntry: (logId, entryId) => request(`/calories/${logId}/entries/${entryId}`, { method: 'DELETE' }),
  history: (days = 7) => request(`/calories/history?days=${days}`),
};

// ---- Water Tracker ----
export const waterApi = {
  get: (date) => request(`/water${date ? `?date=${date}` : ''}`),
  log: (amountMl, date) => request('/water', { method: 'POST', body: { amountMl, date } }),
  removeEntry: (logId, entryId) => request(`/water/${logId}/entries/${entryId}`, { method: 'DELETE' }),
  history: (days = 7) => request(`/water/history?days=${days}`),
};

// ---- Exercise Tracker ----
export const exerciseApi = {
  get: (date) => request(`/exercise${date ? `?date=${date}` : ''}`),
  log: (payload) => request('/exercise', { method: 'POST', body: payload }),
  remove: (id) => request(`/exercise/${id}`, { method: 'DELETE' }),
  history: (days = 7) => request(`/exercise/history?days=${days}`),
};

// ---- Meal Planner ----
export const mealPlanApi = {
  get: (date) => request(`/meal-plans${date ? `?date=${date}` : ''}`),
  range: (start, end) => request(`/meal-plans/range?start=${start}&end=${end}`),
  save: (payload) => request('/meal-plans', { method: 'PUT', body: payload }),
  addMeal: (payload) => request('/meal-plans/meal', { method: 'POST', body: payload }),
  removeMeal: (planId, mealId) => request(`/meal-plans/${planId}/meals/${mealId}`, { method: 'DELETE' }),
};

export { getToken };
export function setToken(token) {
  if (token) localStorage.setItem('ht_token', token);
  else localStorage.removeItem('ht_token');
}
