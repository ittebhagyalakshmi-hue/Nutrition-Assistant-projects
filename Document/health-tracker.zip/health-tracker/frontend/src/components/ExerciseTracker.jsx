import React, { useEffect, useState } from 'react';
import { exerciseApi } from '../api/api';
import './ExerciseTracker.css';

const TYPES = ['cardio', 'strength', 'flexibility', 'sports', 'other'];
const INTENSITIES = ['low', 'medium', 'high'];
const EMPTY = { name: '', type: 'cardio', durationMin: '', caloriesBurned: '', intensity: 'medium', notes: '' };

export default function ExerciseTracker() {
  const [data, setData] = useState(null);
  const [form, setForm] = useState(EMPTY);
  const [error, setError] = useState('');

  const load = () => exerciseApi.get().then(setData).catch((e) => setError(e.message));
  useEffect(() => { load(); }, []);

  const update = (field) => (e) => setForm((f) => ({ ...f, [field]: e.target.value }));

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    try {
      await exerciseApi.log({
        ...form,
        durationMin: Number(form.durationMin),
        caloriesBurned: Number(form.caloriesBurned || 0),
      });
      setForm(EMPTY);
      load();
    } catch (err) {
      setError(err.message);
    }
  };

  const remove = async (id) => {
    try {
      await exerciseApi.remove(id);
      load();
    } catch (err) {
      setError(err.message);
    }
  };

  if (!data) return <div className="ht-empty">Loading workouts…</div>;

  return (
    <div className="ht-exercise">
      <h1>Exercise Tracker</h1>
      <p className="ht-sub">Log workouts and track calories burned.</p>

      {error && <div className="ht-error">{error}</div>}

      <div className="ht-grid-3 ht-exercise-summary">
        <div className="ht-card">
          <div className="ht-eyebrow">Sessions</div>
          <div className="ht-tile-value">{data.entries.length}</div>
        </div>
        <div className="ht-card">
          <div className="ht-eyebrow">Minutes moved</div>
          <div className="ht-tile-value">{data.totalMinutes}</div>
        </div>
        <div className="ht-card">
          <div className="ht-eyebrow">Calories burned</div>
          <div className="ht-tile-value">{data.totalCaloriesBurned}</div>
        </div>
      </div>

      <form className="ht-card ht-exercise-form" onSubmit={submit}>
        <div className="ht-eyebrow">Log a workout</div>
        <div className="ht-grid-3">
          <div className="ht-field"><label>Name</label><input className="ht-input" value={form.name} onChange={update('name')} required /></div>
          <div className="ht-field">
            <label>Type</label>
            <select className="ht-select" value={form.type} onChange={update('type')}>
              {TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>
          <div className="ht-field">
            <label>Intensity</label>
            <select className="ht-select" value={form.intensity} onChange={update('intensity')}>
              {INTENSITIES.map((i) => <option key={i} value={i}>{i}</option>)}
            </select>
          </div>
          <div className="ht-field"><label>Duration (min)</label><input type="number" className="ht-input" value={form.durationMin} onChange={update('durationMin')} required /></div>
          <div className="ht-field"><label>Calories burned</label><input type="number" className="ht-input" value={form.caloriesBurned} onChange={update('caloriesBurned')} /></div>
          <div className="ht-field"><label>Notes</label><input className="ht-input" value={form.notes} onChange={update('notes')} /></div>
        </div>
        <button className="ht-btn ht-btn-primary">Log workout</button>
      </form>

      <div className="ht-card">
        <div className="ht-card-header"><h3>Today's workouts</h3></div>
        {data.entries.length === 0 ? (
          <div className="ht-empty">No workouts logged yet today.</div>
        ) : (
          data.entries.map((ex) => (
            <div key={ex._id} className="ht-exercise-entry">
              <div>
                <div className="ht-exercise-entry-name">{ex.name} <span className="ht-food-tag">{ex.type}</span></div>
                <div className="ht-exercise-entry-sub">{ex.durationMin} min · {ex.intensity} intensity{ex.notes ? ` · ${ex.notes}` : ''}</div>
              </div>
              <div className="ht-cal-entry-right">
                <span>{ex.caloriesBurned} kcal</span>
                <button className="ht-food-delete" onClick={() => remove(ex._id)}>×</button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
