import React, { useState } from 'react';
import { authApi, setToken } from '../api/api';
import './AuthScreen.css';

export default function AuthScreen({ onAuthenticated }) {
  const [mode, setMode] = useState('login'); // 'login' | 'register'
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const update = (field) => (e) => setForm((f) => ({ ...f, [field]: e.target.value }));

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const data =
        mode === 'login'
          ? await authApi.login({ email: form.email, password: form.password })
          : await authApi.register(form);
      setToken(data.token);
      onAuthenticated(data.user);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="ht-auth">
      <div className="ht-auth-card ht-card">
        <div className="ht-auth-brand">Verdant</div>
        <h2>{mode === 'login' ? 'Welcome back' : 'Create your account'}</h2>
        <p className="ht-auth-sub">
          {mode === 'login' ? 'Log in to see today\u2019s progress.' : 'Start tracking meals, water, and workouts.'}
        </p>

        {error && <div className="ht-error">{error}</div>}

        <form onSubmit={submit}>
          {mode === 'register' && (
            <div className="ht-field">
              <label htmlFor="name">Name</label>
              <input id="name" className="ht-input" value={form.name} onChange={update('name')} required />
            </div>
          )}
          <div className="ht-field">
            <label htmlFor="email">Email</label>
            <input id="email" type="email" className="ht-input" value={form.email} onChange={update('email')} required />
          </div>
          <div className="ht-field">
            <label htmlFor="password">Password</label>
            <input id="password" type="password" className="ht-input" value={form.password} onChange={update('password')} required minLength={6} />
          </div>
          <button className="ht-btn ht-btn-primary ht-auth-submit" disabled={loading}>
            {loading ? 'Please wait…' : mode === 'login' ? 'Log in' : 'Sign up'}
          </button>
        </form>

        <button className="ht-auth-switch" onClick={() => setMode(mode === 'login' ? 'register' : 'login')}>
          {mode === 'login' ? "Don't have an account? Sign up" : 'Already have an account? Log in'}
        </button>
      </div>
    </div>
  );
}
