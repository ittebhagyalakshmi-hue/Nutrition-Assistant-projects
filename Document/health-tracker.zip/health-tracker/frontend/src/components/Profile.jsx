import React, { useEffect, useState } from 'react';
import { profileApi } from '../api/api';
import './Profile.css';

const ACTIVITY_LEVELS = [
  { value: 'sedentary', label: 'Sedentary (little exercise)' },
  { value: 'light', label: 'Light (1-3 days/week)' },
  { value: 'moderate', label: 'Moderate (3-5 days/week)' },
  { value: 'active', label: 'Active (6-7 days/week)' },
  { value: 'very_active', label: 'Very active (physical job / 2x/day)' },
];

const GOALS = [
  { value: 'lose_weight', label: 'Lose weight' },
  { value: 'maintain', label: 'Maintain weight' },
  { value: 'gain_muscle', label: 'Gain muscle' },
];

export default function Profile() {
  const [form, setForm] = useState(null);
  const [tdee, setTdee] = useState(null);
  const [status, setStatus] = useState('');
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    profileApi.get().then(setForm).catch((e) => setError(e.message));
  }, []);

  const update = (field) => (e) => {
    const value = e.target.type === 'number' ? Number(e.target.value) : e.target.value;
    setForm((f) => ({ ...f, [field]: value }));
  };

  const save = async (e) => {
    e.preventDefault();
    setSaving(true);
    setError('');
    setStatus('');
    try {
      const updated = await profileApi.update(form);
      setForm(updated);
      setStatus('Profile saved');
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  const getSuggestion = async () => {
    setError('');
    try {
      const result = await profileApi.tdee();
      setTdee(result);
    } catch (err) {
      setError(err.message);
    }
  };

  if (!form) return <div className="ht-empty">Loading profile…</div>;

  return (
    <div className="ht-profile">
      <h1>Profile</h1>
      <p className="ht-sub">Your details power calorie goals, BMI, and recommendations.</p>

      {error && <div className="ht-error">{error}</div>}
      {status && <div className="ht-status">{status}</div>}

      <form className="ht-card" onSubmit={save}>
        <div className="ht-grid-2">
          <div className="ht-field">
            <label>Name</label>
            <input className="ht-input" value={form.name || ''} onChange={update('name')} />
          </div>
          <div className="ht-field">
            <label>Age</label>
            <input type="number" className="ht-input" value={form.age || ''} onChange={update('age')} />
          </div>
          <div className="ht-field">
            <label>Gender</label>
            <select className="ht-select" value={form.gender || 'other'} onChange={update('gender')}>
              <option value="male">Male</option>
              <option value="female">Female</option>
              <option value="other">Other</option>
            </select>
          </div>
          <div className="ht-field">
            <label>Activity level</label>
            <select className="ht-select" value={form.activityLevel} onChange={update('activityLevel')}>
              {ACTIVITY_LEVELS.map((a) => (
                <option key={a.value} value={a.value}>{a.label}</option>
              ))}
            </select>
          </div>
          <div className="ht-field">
            <label>Height (cm)</label>
            <input type="number" className="ht-input" value={form.heightCm || ''} onChange={update('heightCm')} />
          </div>
          <div className="ht-field">
            <label>Weight (kg)</label>
            <input type="number" className="ht-input" value={form.weightKg || ''} onChange={update('weightKg')} />
          </div>
          <div className="ht-field">
            <label>Goal</label>
            <select className="ht-select" value={form.goal} onChange={update('goal')}>
              {GOALS.map((g) => (
                <option key={g.value} value={g.value}>{g.label}</option>
              ))}
            </select>
          </div>
          <div className="ht-field">
            <label>Daily calorie goal (kcal)</label>
            <input type="number" className="ht-input" value={form.dailyCalorieGoal} onChange={update('dailyCalorieGoal')} />
          </div>
          <div className="ht-field">
            <label>Daily water goal (mL)</label>
            <input type="number" className="ht-input" value={form.dailyWaterGoalMl} onChange={update('dailyWaterGoalMl')} />
          </div>
        </div>

        <div className="ht-profile-actions">
          <button className="ht-btn ht-btn-primary" disabled={saving}>{saving ? 'Saving…' : 'Save changes'}</button>
          <button type="button" className="ht-btn ht-btn-ghost" onClick={getSuggestion}>Suggest calorie goal</button>
        </div>

        {tdee && (
          <div className="ht-profile-tdee">
            Based on your profile, maintenance is about <strong>{tdee.tdee} kcal/day</strong>; your goal suggests{' '}
            <strong>{tdee.recommendedCalories} kcal/day</strong>.
          </div>
        )}
      </form>
    </div>
  );
}
