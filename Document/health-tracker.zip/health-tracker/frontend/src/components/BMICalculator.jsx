import React, { useEffect, useState } from 'react';
import { bmiApi } from '../api/api';
import './BMICalculator.css';

function categoryColor(category) {
  switch (category) {
    case 'Underweight': return 'var(--color-water)';
    case 'Normal weight': return 'var(--color-primary)';
    case 'Overweight': return 'var(--color-accent)';
    default: return 'var(--color-danger)';
  }
}

export default function BMICalculator() {
  const [heightCm, setHeightCm] = useState('');
  const [weightKg, setWeightKg] = useState('');
  const [result, setResult] = useState(null);
  const [history, setHistory] = useState([]);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const loadHistory = () => bmiApi.history().then(setHistory).catch((e) => setError(e.message));

  useEffect(() => { loadHistory(); }, []);

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);
    try {
      const record = await bmiApi.calculate({ heightCm: Number(heightCm), weightKg: Number(weightKg) });
      setResult(record);
      loadHistory();
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="ht-bmi">
      <h1>BMI Calculator</h1>
      <p className="ht-sub">Track your Body Mass Index over time.</p>

      {error && <div className="ht-error">{error}</div>}

      <div className="ht-grid-2">
        <form className="ht-card" onSubmit={submit}>
          <div className="ht-field">
            <label>Height (cm)</label>
            <input className="ht-input" type="number" value={heightCm} onChange={(e) => setHeightCm(e.target.value)} required />
          </div>
          <div className="ht-field">
            <label>Weight (kg)</label>
            <input className="ht-input" type="number" value={weightKg} onChange={(e) => setWeightKg(e.target.value)} required />
          </div>
          <button className="ht-btn ht-btn-primary" disabled={loading}>{loading ? 'Calculating…' : 'Calculate BMI'}</button>
        </form>

        <div className="ht-card ht-bmi-result">
          {result ? (
            <>
              <div className="ht-eyebrow">Your result</div>
              <div className="ht-bmi-value" style={{ color: categoryColor(result.category) }}>{result.bmi}</div>
              <div className="ht-bmi-category" style={{ color: categoryColor(result.category) }}>{result.category}</div>
              <div className="ht-bmi-scale">
                {['Underweight', 'Normal weight', 'Overweight', 'Obese'].map((c) => (
                  <span key={c} className={`ht-bmi-scale-seg ${result.category === c ? 'is-active' : ''}`}>{c}</span>
                ))}
              </div>
            </>
          ) : (
            <div className="ht-empty">Enter your height and weight to calculate BMI.</div>
          )}
        </div>
      </div>

      <div className="ht-card ht-bmi-history">
        <div className="ht-card-header"><h3>History</h3></div>
        {history.length === 0 ? (
          <div className="ht-empty">No BMI records yet.</div>
        ) : (
          <table className="ht-table">
            <thead>
              <tr><th>Date</th><th>Height</th><th>Weight</th><th>BMI</th><th>Category</th></tr>
            </thead>
            <tbody>
              {history.map((r) => (
                <tr key={r._id}>
                  <td>{new Date(r.recordedAt).toLocaleDateString()}</td>
                  <td>{r.heightCm} cm</td>
                  <td>{r.weightKg} kg</td>
                  <td>{r.bmi}</td>
                  <td style={{ color: categoryColor(r.category) }}>{r.category}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
