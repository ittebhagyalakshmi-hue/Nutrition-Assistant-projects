import React from 'react';

// Signature element: circular progress ring used across the Dashboard
// to show goal completion at a glance (calories, water, minutes moved).
export default function RingStat({ value, goal, label, sublabel, color, size = 108 }) {
  const pct = goal > 0 ? Math.min(value / goal, 1) : 0;
  const stroke = 10;
  const radius = (size - stroke) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference * (1 - pct);

  return (
    <div className="ht-ring" style={{ width: size }}>
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke="var(--color-border)"
          strokeWidth={stroke}
        />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={color}
          strokeWidth={stroke}
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          transform={`rotate(-90 ${size / 2} ${size / 2})`}
          style={{ transition: 'stroke-dashoffset 0.5s ease' }}
        />
        <text x="50%" y="47%" textAnchor="middle" className="ht-ring-value">
          {Math.round(pct * 100)}%
        </text>
      </svg>
      <div className="ht-ring-label">{label}</div>
      <div className="ht-ring-sublabel">{sublabel}</div>
    </div>
  );
}
