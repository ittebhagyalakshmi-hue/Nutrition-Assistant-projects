import React, { useEffect, useState } from 'react';
import { calorieApi } from '../api/api';
import FoodPicker from './FoodPicker';
import './CalorieTracker.css';

const MEAL_TYPES = ['breakfast', 'lunch', 'dinner', 'snack'];

export default function CalorieTracker() {
  const [log, setLog] = useState(null);
  const [mealType, setMealType] = useState('breakfast');
  const [servings, setServings] = useState(1);
  const [pendingFood, setPendingFood] = useState(null);
  const [error, setError] = useState('');

  const load = () => calorieApi.get().then(setLog).catch((e) => setError(e.message));
  useEffect(() => { load(); }, []);

  const addEntry = async () => {
    if (!pendingFood) return;
    setError('');
    try {
      const updated = await calorieApi.log({ foodItemId: pendingFood._id, servings: Number(servings), mealType });
      setLog(updated);
      setPendingFood(null);
      setServings(1);
    } catch (err) {
      setError(err.message);
    }
  };

  const removeEntry = async (entryId) => {
    try {
      const updated = await calorieApi.removeEntry(log._id, entryId);
      setLog(updated.log);
    } catch (err) {
      setError(err.message);
    }
  };

  if (!log) return <div className="ht-empty">Loading calorie log…</div>;

  const total = log.totalCalories || 0;
  const goal = log.calorieGoal || 2000;
  const pct = Math.min(100, Math.round((total / goal) * 100));

  return (
    <div className="ht-calories">
      <h1>Calorie Tracker</h1>
      <p className="ht-sub">Log meals against your daily goal.</p>

      {error && <div className="ht-error">{error}</div>}

      <div className="ht-card ht-cal-summary">
        <div>
          <div className="ht-eyebrow">Today</div>
          <div className="ht-cal-total">{total} <span>/ {goal} kcal</span></div>
        </div>
        <div className="ht-cal-bar">
          <div className="ht-cal-bar-fill" style={{ width: `${pct}%` }} />
        </div>
      </div>

      <div className="ht-card ht-cal-add">
        <div className="ht-eyebrow">Add food</div>
        <div className="ht-cal-add-row">
          <FoodPicker onSelect={setPendingFood} />
          <input
            type="number"
            min="0.1"
            step="0.1"
            className="ht-input ht-cal-servings"
            value={servings}
            onChange={(e) => setServings(e.target.value)}
          />
          <select className="ht-select ht-cal-mealtype" value={mealType} onChange={(e) => setMealType(e.target.value)}>
            {MEAL_TYPES.map((m) => <option key={m} value={m}>{m}</option>)}
          </select>
          <button className="ht-btn ht-btn-primary" disabled={!pendingFood} onClick={addEntry}>Add</button>
        </div>
        {pendingFood && (
          <div className="ht-cal-pending">Selected: {pendingFood.name} ({pendingFood.caloriesPerServing} kcal/serving)</div>
        )}
      </div>

      {MEAL_TYPES.map((type) => {
        const entries = (log.entries || []).filter((e) => e.mealType === type);
        if (entries.length === 0) return null;
        return (
          <div key={type} className="ht-card ht-cal-meal">
            <div className="ht-card-header"><h3 style={{ textTransform: 'capitalize' }}>{type}</h3></div>
            {entries.map((e) => (
              <div key={e._id} className="ht-cal-entry">
                <div>
                  <div className="ht-cal-entry-name">{e.foodItem?.name || 'Food'}</div>
                  <div className="ht-cal-entry-sub">{e.servings} serving(s)</div>
                </div>
                <div className="ht-cal-entry-right">
                  <span>{e.calories} kcal</span>
                  <button className="ht-food-delete" onClick={() => removeEntry(e._id)}>×</button>
                </div>
              </div>
            ))}
          </div>
        );
      })}

      {(!log.entries || log.entries.length === 0) && <div className="ht-empty">No food logged yet today.</div>}
    </div>
  );
}
