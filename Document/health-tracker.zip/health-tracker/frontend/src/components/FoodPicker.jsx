import React, { useEffect, useState } from 'react';
import { foodApi } from '../api/api';
import './FoodPicker.css';

// Reusable typeahead used by Calorie Tracker and Meal Planner to select a food item.
export default function FoodPicker({ onSelect, placeholder = 'Search food to add…' }) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (!query) { setResults([]); return; }
    const t = setTimeout(() => {
      foodApi.list({ search: query, limit: 8 }).then((d) => setResults(d.items));
    }, 250);
    return () => clearTimeout(t);
  }, [query]);

  const pick = (item) => {
    onSelect(item);
    setQuery('');
    setResults([]);
    setOpen(false);
  };

  return (
    <div className="ht-food-picker">
      <input
        className="ht-input"
        placeholder={placeholder}
        value={query}
        onChange={(e) => { setQuery(e.target.value); setOpen(true); }}
        onFocus={() => setOpen(true)}
      />
      {open && results.length > 0 && (
        <div className="ht-food-picker-results">
          {results.map((item) => (
            <button type="button" key={item._id} className="ht-food-picker-item" onClick={() => pick(item)}>
              <span>{item.name}</span>
              <span className="ht-food-picker-cal">{item.caloriesPerServing} kcal</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
