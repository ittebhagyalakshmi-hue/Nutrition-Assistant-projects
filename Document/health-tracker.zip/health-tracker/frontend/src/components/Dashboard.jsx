import React, { useEffect, useState } from 'react';
import { dashboardApi } from '../api/api';
import RingStat from './RingStat';
import './Dashboard.css';

export default function Dashboard({ onNavigate }) {
  const [data, setData] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;
    dashboardApi
      .get()
      .then((d) => mounted && setData(d))
      .catch((e) => mounted && setError(e.message))
      .finally(() => mounted && setLoading(false));
    return () => { mounted = false; };
  }, []);

  if (loading) return <div className="ht-empty">Loading your day…</div>;
  if (error) return <div className="ht-error">{error}</div>;
  if (!data) return null;

  const { calories, water, exercise, bmi, user, date } = data;

  return (
    <div className="ht-dash">
      <div className="ht-dash-head">
        <div>
          <div className="ht-eyebrow">{new Date(date).toDateString()}</div>
          <h1>Hi {user.name.split(' ')[0]}, here's today</h1>
        </div>
      </div>

      <div className="ht-card ht-dash-rings">
        <RingStat
          value={calories.consumed}
          goal={calories.goal}
          label="Calories"
          sublabel={`${calories.consumed} / ${calories.goal} kcal`}
          color="var(--color-accent)"
        />
        <RingStat
          value={water.consumedMl}
          goal={water.goalMl}
          label="Water"
          sublabel={`${(water.consumedMl / 1000).toFixed(1)} / ${(water.goalMl / 1000).toFixed(1)} L`}
          color="var(--color-water)"
        />
        <RingStat
          value={exercise.totalMinutes}
          goal={30}
          label="Movement"
          sublabel={`${exercise.totalMinutes} min moved`}
          color="var(--color-primary)"
        />
      </div>

      <div className="ht-grid-3 ht-dash-tiles">
        <button className="ht-card ht-tile" onClick={() => onNavigate('calories')}>
          <div className="ht-eyebrow">Net calories</div>
          <div className="ht-tile-value">{calories.net}</div>
          <div className="ht-tile-sub">{calories.burned} kcal burned via exercise</div>
        </button>
        <button className="ht-card ht-tile" onClick={() => onNavigate('bmi')}>
          <div className="ht-eyebrow">BMI</div>
          <div className="ht-tile-value">{bmi ? bmi.value : '—'}</div>
          <div className="ht-tile-sub">{bmi ? bmi.category : 'Add height & weight'}</div>
        </button>
        <button className="ht-card ht-tile" onClick={() => onNavigate('exercise')}>
          <div className="ht-eyebrow">Workouts today</div>
          <div className="ht-tile-value">{exercise.sessionCount}</div>
          <div className="ht-tile-sub">{exercise.totalMinutes} minutes total</div>
        </button>
      </div>

      <div className="ht-dash-quick">
        <button className="ht-btn ht-btn-primary" onClick={() => onNavigate('calories')}>Log a meal</button>
        <button className="ht-btn ht-btn-ghost" onClick={() => onNavigate('water')}>Log water</button>
        <button className="ht-btn ht-btn-ghost" onClick={() => onNavigate('exercise')}>Log workout</button>
        <button className="ht-btn ht-btn-ghost" onClick={() => onNavigate('meals')}>Plan meals</button>
      </div>
    </div>
  );
}
