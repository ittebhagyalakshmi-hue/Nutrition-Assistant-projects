import React, { useEffect, useState } from 'react';
import { waterApi } from '../api/api';
import './WaterTracker.css';

const QUICK_AMOUNTS = [200, 250, 350, 500];

export default function WaterTracker() {
  const [log, setLog] = useState(null);
  const [custom, setCustom] = useState('');
  const [error, setError] = useState('');

  const load = () => waterApi.get().then(setLog).catch((e) => setError(e.message));
  useEffect(() => { load(); }, []);

  const addWater = async (amountMl) => {
    setError('');
    try {
      const updated = await waterApi.log(amountMl);
      setLog(updated);
    } catch (err) {
      setError(err.message);
    }
  };

  const removeEntry = async (entryId) => {
    try {
      const updated = await waterApi.removeEntry(log._id, entryId);
      setLog(updated);
    } catch (err) {
      setError(err.message);
    }
  };

  if (!log) return <div className="ht-empty">Loading water log…</div>;

  const total = log.totalMl || 0;
  const goal = log.goalMl || 2500;
  const pct = Math.min(100, Math.round((total / goal) * 100));
  const glassCount = Math.round(goal / 250);
  const filledGlasses = Math.round(total / 250);

  return (
    <div className="ht-water">
      <h1>Water Intake</h1>
      <p className="ht-sub">Stay on top of daily hydration.</p>

      {error && <div className="ht-error">{error}</div>}

      <div className="ht-card ht-water-summary">
        <div className="ht-water-total">
          {(total / 1000).toFixed(2)} L <span>/ {(goal / 1000).toFixed(2)} L ({pct}%)</span>
        </div>
        <div className="ht-water-glasses">
          {Array.from({ length: glassCount }).map((_, i) => (
            <span key={i} className={`ht-glass ${i < filledGlasses ? 'is-filled' : ''}`} />
          ))}
        </div>
      </div>

      <div className="ht-card">
        <div className="ht-eyebrow">Quick add</div>
        <div className="ht-water-quick">
          {QUICK_AMOUNTS.map((ml) => (
            <button key={ml} className="ht-btn ht-btn-ghost" onClick={() => addWater(ml)}>+{ml} mL</button>
          ))}
        </div>
        <div className="ht-water-custom">
          <input
            type="number"
            className="ht-input"
            placeholder="Custom amount (mL)"
            value={custom}
            onChange={(e) => setCustom(e.target.value)}
          />
          <button
            className="ht-btn ht-btn-primary"
            onClick={() => { if (custom) { addWater(Number(custom)); setCustom(''); } }}
          >
            Add
          </button>
        </div>
      </div>

      <div className="ht-card ht-water-log">
        <div className="ht-card-header"><h3>Today's entries</h3></div>
        {(!log.entries || log.entries.length === 0) ? (
          <div className="ht-empty">No water logged yet today.</div>
        ) : (
          log.entries.slice().reverse().map((e) => (
            <div key={e._id} className="ht-water-entry">
              <span>{e.amountMl} mL</span>
              <span className="ht-water-entry-time">{new Date(e.loggedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
              <button className="ht-food-delete" onClick={() => removeEntry(e._id)}>×</button>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
