import React from 'react';
import './NavBar.css';

const TABS = [
  { key: 'dashboard', label: 'Dashboard' },
  { key: 'profile', label: 'Profile' },
  { key: 'bmi', label: 'BMI' },
  { key: 'meals', label: 'Meal Planner' },
  { key: 'foods', label: 'Food Database' },
  { key: 'calories', label: 'Calories' },
  { key: 'water', label: 'Water' },
  { key: 'exercise', label: 'Exercise' },
];

export default function NavBar({ active, onNavigate, userName, onLogout }) {
  return (
    <header className="ht-nav">
      <div className="ht-nav-inner">
        <div className="ht-nav-brand">
          <span className="ht-nav-mark" aria-hidden="true" />
          <span>Verdant</span>
        </div>
        <nav className="ht-nav-tabs">
          {TABS.map((t) => (
            <button
              key={t.key}
              className={`ht-nav-tab ${active === t.key ? 'is-active' : ''}`}
              onClick={() => onNavigate(t.key)}
            >
              {t.label}
            </button>
          ))}
        </nav>
        <div className="ht-nav-user">
          <span className="ht-nav-username">{userName}</span>
          <button className="ht-btn ht-btn-ghost" onClick={onLogout}>Log out</button>
        </div>
      </div>
    </header>
  );
}
