import React, { useEffect, useState } from 'react';
import { mealPlanApi } from '../api/api';
import FoodPicker from './FoodPicker';
import './MealPlanner.css';

const MEAL_TYPES = ['breakfast', 'lunch', 'dinner', 'snack'];

function startOfWeek(date) {
  const d = new Date(date);
  const day = d.getDay();
  const diff = d.getDate() - day; // Sunday as start
  return new Date(d.setDate(diff));
}

function toISO(d) { return d.toISOString().slice(0, 10); }

function buildWeekDates(anchor) {
  const start = startOfWeek(anchor);
  return Array.from({ length: 7 }).map((_, i) => {
    const d = new Date(start);
    d.setDate(start.getDate() + i);
    return toISO(d);
  });
}

export default function MealPlanner() {
  const [anchor, setAnchor] = useState(new Date());
  const [plans, setPlans] = useState({}); // date -> plan
  const [activeCell, setActiveCell] = useState(null); // { date, mealType }
  const [error, setError] = useState('');

  const weekDates = buildWeekDates(anchor);

  const load = () => {
    mealPlanApi
      .range(weekDates[0], weekDates[6])
      .then((list) => {
        const byDate = {};
        list.forEach((p) => { byDate[p.date] = p; });
        setPlans(byDate);
      })
      .catch((e) => setError(e.message));
  };

  useEffect(() => { load(); }, [weekDates[0]]); // eslint-disable-line

  const addMeal = async (date, mealType, foodItem) => {
    setError('');
    try {
      const plan = await mealPlanApi.addMeal({ date, foodItemId: foodItem._id, servings: 1, mealType });
      setPlans((p) => ({ ...p, [date]: plan }));
      setActiveCell(null);
    } catch (err) {
      setError(err.message);
    }
  };

  const removeMeal = async (plan, mealId) => {
    try {
      const updated = await mealPlanApi.removeMeal(plan._id, mealId);
      setPlans((p) => ({ ...p, [updated.date]: updated }));
    } catch (err) {
      setError(err.message);
    }
  };

  const shiftWeek = (delta) => {
    const d = new Date(anchor);
    d.setDate(d.getDate() + delta * 7);
    setAnchor(d);
  };

  return (
    <div className="ht-meal-planner">
      <div className="ht-mp-head">
        <div>
          <h1>Meal Planner</h1>
          <p className="ht-sub">Plan meals across the week.</p>
        </div>
        <div className="ht-mp-nav">
          <button className="ht-btn ht-btn-ghost" onClick={() => shiftWeek(-1)}>← Prev week</button>
          <button className="ht-btn ht-btn-ghost" onClick={() => shiftWeek(1)}>Next week →</button>
        </div>
      </div>

      {error && <div className="ht-error">{error}</div>}

      <div className="ht-mp-grid">
        <div className="ht-mp-corner" />
        {weekDates.map((date) => (
          <div key={date} className="ht-mp-day-header">
            <div className="ht-mp-day-name">{new Date(date).toLocaleDateString(undefined, { weekday: 'short' })}</div>
            <div className="ht-mp-day-num">{new Date(date).getDate()}</div>
          </div>
        ))}

        {MEAL_TYPES.map((mealType) => (
          <React.Fragment key={mealType}>
            <div className="ht-mp-row-label">{mealType}</div>
            {weekDates.map((date) => {
              const plan = plans[date];
              const meals = plan ? plan.meals.filter((m) => m.mealType === mealType) : [];
              const isActive = activeCell && activeCell.date === date && activeCell.mealType === mealType;
              return (
                <div key={date + mealType} className="ht-mp-cell">
                  {meals.map((m) => (
                    <div key={m._id} className="ht-mp-chip">
                      <span>{m.foodItem?.name || 'Food'}</span>
                      <button onClick={() => removeMeal(plan, m._id)} aria-label="Remove meal">×</button>
                    </div>
                  ))}
                  {isActive ? (
                    <FoodPicker onSelect={(food) => addMeal(date, mealType, food)} placeholder="Add…" />
                  ) : (
                    <button className="ht-mp-add" onClick={() => setActiveCell({ date, mealType })}>+ add</button>
                  )}
                </div>
              );
            })}
          </React.Fragment>
        ))}
      </div>
    </div>
  );
}
