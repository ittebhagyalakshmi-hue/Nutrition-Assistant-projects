import React, { useEffect, useState } from 'react';
import { foodApi } from '../api/api';
import './FoodDatabase.css';

const CATEGORIES = ['fruit', 'vegetable', 'grain', 'protein', 'dairy', 'fat', 'beverage', 'snack', 'other'];
const EMPTY_FORM = {
  name: '', brand: '', category: 'other', servingSize: 100, servingUnit: 'g',
  caloriesPerServing: '', macros: { proteinG: 0, carbsG: 0, fatG: 0, fiberG: 0, sugarG: 0 },
};

export default function FoodDatabase() {
  const [items, setItems] = useState([]);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(EMPTY_FORM);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);

  const load = () => {
    setLoading(true);
    foodApi
      .list({ search, category })
      .then((d) => setItems(d.items))
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []); // eslint-disable-line
  useEffect(() => {
    const t = setTimeout(load, 300);
    return () => clearTimeout(t);
  }, [search, category]); // eslint-disable-line

  const updateForm = (field) => (e) => setForm((f) => ({ ...f, [field]: e.target.value }));
  const updateMacro = (field) => (e) =>
    setForm((f) => ({ ...f, macros: { ...f.macros, [field]: Number(e.target.value) } }));

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    try {
      await foodApi.create({
        ...form,
        servingSize: Number(form.servingSize),
        caloriesPerServing: Number(form.caloriesPerServing),
      });
      setForm(EMPTY_FORM);
      setShowForm(false);
      load();
    } catch (err) {
      setError(err.message);
    }
  };

  const remove = async (id) => {
    try {
      await foodApi.remove(id);
      load();
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div className="ht-foods">
      <div className="ht-foods-head">
        <div>
          <h1>Food Database</h1>
          <p className="ht-sub">Search foods or add your own.</p>
        </div>
        <button className="ht-btn ht-btn-primary" onClick={() => setShowForm((s) => !s)}>
          {showForm ? 'Close' : '+ Add food'}
        </button>
      </div>

      {error && <div className="ht-error">{error}</div>}

      {showForm && (
        <form className="ht-card ht-food-form" onSubmit={submit}>
          <div className="ht-grid-3">
            <div className="ht-field"><label>Name</label><input className="ht-input" value={form.name} onChange={updateForm('name')} required /></div>
            <div className="ht-field"><label>Brand (optional)</label><input className="ht-input" value={form.brand} onChange={updateForm('brand')} /></div>
            <div className="ht-field">
              <label>Category</label>
              <select className="ht-select" value={form.category} onChange={updateForm('category')}>
                {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </div>
            <div className="ht-field"><label>Serving size</label><input type="number" className="ht-input" value={form.servingSize} onChange={updateForm('servingSize')} required /></div>
            <div className="ht-field"><label>Serving unit</label><input className="ht-input" value={form.servingUnit} onChange={updateForm('servingUnit')} required /></div>
            <div className="ht-field"><label>Calories / serving</label><input type="number" className="ht-input" value={form.caloriesPerServing} onChange={updateForm('caloriesPerServing')} required /></div>
            <div className="ht-field"><label>Protein (g)</label><input type="number" className="ht-input" value={form.macros.proteinG} onChange={updateMacro('proteinG')} /></div>
            <div className="ht-field"><label>Carbs (g)</label><input type="number" className="ht-input" value={form.macros.carbsG} onChange={updateMacro('carbsG')} /></div>
            <div className="ht-field"><label>Fat (g)</label><input type="number" className="ht-input" value={form.macros.fatG} onChange={updateMacro('fatG')} /></div>
          </div>
          <button className="ht-btn ht-btn-primary">Save food</button>
        </form>
      )}

      <div className="ht-food-filters">
        <input className="ht-input" placeholder="Search foods…" value={search} onChange={(e) => setSearch(e.target.value)} />
        <select className="ht-select" value={category} onChange={(e) => setCategory(e.target.value)}>
          <option value="">All categories</option>
          {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
        </select>
      </div>

      {loading ? (
        <div className="ht-empty">Loading foods…</div>
      ) : items.length === 0 ? (
        <div className="ht-empty">No foods found. Try adding one.</div>
      ) : (
        <div className="ht-food-grid">
          {items.map((f) => (
            <div key={f._id} className="ht-card ht-food-card">
              <div className="ht-food-card-top">
                <span className="ht-food-tag">{f.category}</span>
                {f.createdBy && (
                  <button className="ht-food-delete" onClick={() => remove(f._id)} aria-label={`Delete ${f.name}`}>×</button>
                )}
              </div>
              <div className="ht-food-name">{f.name}</div>
              {f.brand && <div className="ht-food-brand">{f.brand}</div>}
              <div className="ht-food-cal">{f.caloriesPerServing} kcal <span>/ {f.servingSize}{f.servingUnit}</span></div>
              <div className="ht-food-macros">
                P {f.macros?.proteinG ?? 0}g · C {f.macros?.carbsG ?? 0}g · F {f.macros?.fatG ?? 0}g
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
