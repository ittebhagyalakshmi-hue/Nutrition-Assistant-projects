# Verdant — Health & Fitness Tracker

Full-stack MERN app covering: User Dashboard, Profile Management, BMI Calculator,
Meal Planner, Food Database, Calorie Tracker, Water Intake Tracker, and Exercise Tracker.

## Stack
- **Backend:** Node.js, Express, MongoDB (Mongoose), JWT auth, bcrypt
- **Frontend:** React (Create React App), fetch-based API layer, plain CSS (no framework)

## Project structure
```
health-tracker/
  backend/
    models/       Mongoose schemas (User, FoodItem, CalorieLog, WaterIntake, Exercise, MealPlan, BmiRecord)
    routes/        Express routers, one per feature
    middleware/    JWT auth middleware
    utils/         BMI / TDEE calculation helpers
    server.js
  frontend/
    src/
      api/api.js    Central fetch client + one export per feature
      components/    One component (+ CSS) per feature, plus NavBar/AuthScreen/App shell
```

## Setup

### Backend
```bash
cd backend
cp .env.example .env   # then set MONGO_URI and JWT_SECRET
npm install
npm run dev             # nodemon, or `npm start` for plain node
```
Runs on `http://localhost:5000`, expects a MongoDB instance at `MONGO_URI`.

### Frontend
```bash
cd frontend
cp .env.example .env    # REACT_APP_API_URL, defaults to http://localhost:5000/api
npm install
npm start
```
Runs on `http://localhost:3000`.

## Auth flow
Register or log in via `/api/auth`, receive a JWT, stored in `localStorage` under `ht_token`.
Every other request attaches `Authorization: Bearer <token>` via the shared `request()` helper
in `frontend/src/api/api.js`.

## API summary
| Feature | Base route |
|---|---|
| Auth | `/api/auth` (register, login, me) |
| Dashboard | `/api/dashboard` (aggregated summary for a given day) |
| Profile | `/api/profile` (get/update, `/tdee` suggestion) |
| BMI | `/api/bmi` (calculate + `/history`) |
| Food Database | `/api/foods` (search/CRUD) |
| Calorie Tracker | `/api/calories` (log/remove entries, `/history`) |
| Water Tracker | `/api/water` (log/remove entries, `/history`) |
| Exercise Tracker | `/api/exercise` (log/remove, `/history`) |
| Meal Planner | `/api/meal-plans` (per-day plan, `/range` for weekly view) |

## Notes
- Dates are handled as `YYYY-MM-DD` strings for logs (calorie/water/meal plan/exercise), so a day's
  data is easy to query and doesn't drift across timezones.
- The Dashboard's ring visualization (`RingStat.jsx`) is intentionally shared/reused visual language
  across calories, water, and movement so progress reads consistently.
- All list/log endpoints are scoped to `req.userId` from the JWT — no cross-user data leakage.
