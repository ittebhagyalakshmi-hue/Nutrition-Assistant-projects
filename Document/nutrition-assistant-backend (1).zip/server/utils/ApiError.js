/**
 * Custom error class used throughout the app to represent
 * predictable, operational errors (e.g. "user not found",
 * "invalid credentials") with an associated HTTP status code.
 */
class ApiError extends Error {
  constructor(statusCode, message) {
    super(message);
    this.statusCode = statusCode;
    this.isOperational = true;
    Error.captureStackTrace(this, this.constructor);
  }
}

module.exports = ApiError;
