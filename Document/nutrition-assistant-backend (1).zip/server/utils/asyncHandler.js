/**
 * Wraps an async Express route/controller function and forwards
 * any thrown errors to the next() middleware (errorMiddleware),
 * removing the need for repetitive try/catch blocks everywhere.
 *
 * Usage: router.get("/", asyncHandler(controllerFn));
 */
const asyncHandler = (fn) => (req, res, next) => {
  Promise.resolve(fn(req, res, next)).catch(next);
};

module.exports = asyncHandler;
