const jwt = require("jsonwebtoken");
const { JWT_SECRET, JWT_EXPIRES_IN } = require("../config/config");

/**
 * Generates a signed JWT containing the user's ID and role.
 * @param {string} userId - MongoDB ObjectId of the user
 * @param {string} role - user's role ("user" | "admin")
 * @returns {string} signed JWT
 */
const generateToken = (userId, role) => {
  return jwt.sign({ id: userId, role }, JWT_SECRET, {
    expiresIn: JWT_EXPIRES_IN,
  });
};

module.exports = generateToken;
