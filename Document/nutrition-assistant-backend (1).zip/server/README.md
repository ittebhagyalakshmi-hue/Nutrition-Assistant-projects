# Nutrition Assistant App — Backend

Node.js + Express + MongoDB (Mongoose) REST API with JWT authentication.

## Setup

1. Install dependencies:
   ```
   npm install
   ```

2. Create a `.env` file in the `server/` root (copy from `.env.example`) and fill in your values:
   ```
   PORT=5000
   NODE_ENV=development
   MONGO_URI=your_mongodb_connection_string
   JWT_SECRET=your_jwt_secret
   JWT_EXPIRES_IN=7d
   CLIENT_URL=http://localhost:5173
   ```

3. Run in development (auto-restart with nodemon):
   ```
   npm run dev
   ```

4. Run in production:
   ```
   npm start
   ```

## API Endpoints

| Method | Endpoint             | Access  | Description                  |
|--------|-----------------------|---------|-------------------------------|
| GET    | /api/health            | Public  | API health check              |
| POST   | /api/auth/register      | Public  | Register a new user           |
| POST   | /api/auth/login         | Public  | Log in and receive a JWT      |
| GET    | /api/auth/me            | Private | Get logged-in user (via token)|
| GET    | /api/users/profile      | Private | Get full user profile         |
| PUT    | /api/users/profile      | Private | Update user profile/health data|

For private routes, send the JWT in the request header:
```
Authorization: Bearer <token>
```

## Folder Structure

```
server/
├── config/          # DB connection & environment config
├── models/          # Mongoose schemas
├── controllers/      # Route handler logic
├── routes/           # Express route definitions
├── middleware/        # Auth, admin, validation, error handling
├── utils/             # Helper functions (JWT, async wrapper, ApiError)
├── app.js             # Express app configuration
├── server.js          # Entry point
└── .env                # Environment variables (not committed)
```
