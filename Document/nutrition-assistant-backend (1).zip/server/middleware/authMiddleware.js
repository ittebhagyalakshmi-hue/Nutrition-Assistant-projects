const jwt = require("jsonwebtoken");
const asyncHandler = require("../utils/asyncHandler");
const ApiError = require("../utils/ApiError");
const User = require("../models/User");
const { JWT_SECRET } = require("../config/config");

/**
 * Middleware that protects private routes.
 * Expects an "Authorization: Bearer <token>" header.
 * Verifies the JWT, fetches the corresponding user (without password),
 * and attaches it to req.user for use in downstream controllers.
 */
const protect = asyncHandler(async (req, res, next) => {
  let token;

  if (
    req.headers.authorization &&
    req.headers.authorization.startsWith("Bearer")
  ) {
    token = req.headers.authorization.split(" ")[1];
  }

  if (!token) {
    throw new ApiError(401, "Not authorized, no token provided");
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET);

    // Attach user to request (excluding password field)
    req.user = await User.findById(decoded.id).select("-password");

    if (!req.user) {
      throw new ApiError(401, "Not authorized, user no longer exists");
    }

    next();
  } catch (error) {
    if (error instanceof ApiError) throw error;
    throw new ApiError(401, "Not authorized, token failed or expired");
  }
});

module.exports = { protect };
