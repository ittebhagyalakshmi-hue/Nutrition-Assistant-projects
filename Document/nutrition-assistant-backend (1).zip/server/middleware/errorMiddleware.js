const { NODE_ENV } = require("../config/config");

/**
 * Catches requests to routes that don't exist and forwards
 * a formatted 404 error to the global error handler below.
 */
const notFound = (req, res, next) => {
  const error = new Error(`Route not found - ${req.originalUrl}`);
  error.statusCode = 404;
  next(error);
};

/**
 * Global error-handling middleware. Must be registered LAST
 * (after all routes) in app.js. Catches:
 *  - ApiError instances thrown deliberately in controllers
 *  - Mongoose CastError (invalid ObjectId)
 *  - Mongoose duplicate key errors (e.g. duplicate email)
 *  - Mongoose ValidationError (schema validation failures)
 *  - JWT errors
 *  - Any other unexpected errors
 */
const errorHandler = (err, req, res, next) => {
  let statusCode = err.statusCode && err.statusCode !== 200 ? err.statusCode : 500;
  let message = err.message || "Internal Server Error";

  // Mongoose bad ObjectId
  if (err.name === "CastError") {
    statusCode = 404;
    message = `Resource not found. Invalid ${err.path}: ${err.value}`;
  }

  // Mongoose duplicate key error
  if (err.code === 11000) {
    statusCode = 400;
    const field = Object.keys(err.keyValue).join(", ");
    message = `Duplicate value entered for field: ${field}`;
  }

  // Mongoose validation error
  if (err.name === "ValidationError") {
    statusCode = 400;
    message = Object.values(err.errors)
      .map((val) => val.message)
      .join(", ");
  }

  // JWT errors
  if (err.name === "JsonWebTokenError") {
    statusCode = 401;
    message = "Invalid token, please log in again";
  }

  if (err.name === "TokenExpiredError") {
    statusCode = 401;
    message = "Your session has expired, please log in again";
  }

  res.status(statusCode).json({
    success: false,
    message,
    // Only expose stack trace in development mode
    stack: NODE_ENV === "development" ? err.stack : undefined,
  });
};

module.exports = { notFound, errorHandler };
