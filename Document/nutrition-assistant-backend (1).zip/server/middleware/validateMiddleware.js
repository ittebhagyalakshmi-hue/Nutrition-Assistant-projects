const { validationResult } = require("express-validator");
const ApiError = require("../utils/ApiError");

/**
 * Runs after express-validator's validation chains (defined in the routes).
 * If any validation errors were collected, formats them and throws
 * a single ApiError with a 400 status code; otherwise passes control on.
 */
const validateRequest = (req, res, next) => {
  const errors = validationResult(req);

  if (!errors.isEmpty()) {
    const messages = errors.array().map((err) => err.msg);
    throw new ApiError(400, messages.join(", "));
  }

  next();
};

module.exports = validateRequest;
