const ApiError = require("../utils/ApiError");

/**
 * Middleware that restricts a route to admin users only.
 * Must be used AFTER the `protect` middleware, since it relies
 * on req.user being already populated.
 */
const adminOnly = (req, res, next) => {
  if (req.user && req.user.role === "admin") {
    return next();
  }
  throw new ApiError(403, "Not authorized as an admin");
};

module.exports = { adminOnly };
