const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const morgan = require("morgan");

const { NODE_ENV, CLIENT_URL } = require("./config/config");
const { notFound, errorHandler } = require("./middleware/errorMiddleware");

const authRoutes = require("./routes/authRoutes");
const userRoutes = require("./routes/userRoutes");

const app = express();

// --------------------- Global Middleware ---------------------

// Security headers
app.use(helmet());

// Enable CORS for the frontend client only
app.use(
  cors({
    origin: CLIENT_URL,
    credentials: true,
  })
);

// HTTP request logger (only in development)
if (NODE_ENV === "development") {
  app.use(morgan("dev"));
}

// Body parsers
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// --------------------- Health Check ---------------------
app.get("/api/health", (req, res) => {
  res.status(200).json({
    success: true,
    message: "Nutrition Assistant API is running",
    environment: NODE_ENV,
  });
});

// --------------------- API Routes ---------------------
app.use("/api/auth", authRoutes);
app.use("/api/users", userRoutes);

// --------------------- Error Handling ---------------------
// 404 handler for undefined routes (must come after all valid routes)
app.use(notFound);

// Global error handler (must be the LAST middleware registered)
app.use(errorHandler);

module.exports = app;
