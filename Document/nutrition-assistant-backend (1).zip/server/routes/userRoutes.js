const express = require("express");
const { body } = require("express-validator");
const {
  getUserProfile,
  updateUserProfile,
} = require("../controllers/userController");
const { protect } = require("../middleware/authMiddleware");
const validateRequest = require("../middleware/validateMiddleware");

const router = express.Router();

// All routes below are protected — require a valid JWT
router.use(protect);

/**
 * @route   GET /api/users/profile
 * @desc    Get logged-in user's profile
 * @access  Private
 */
router.get("/profile", getUserProfile);

/**
 * @route   PUT /api/users/profile
 * @desc    Update logged-in user's profile
 * @access  Private
 */
router.put(
  "/profile",
  [
    body("age").optional().isInt({ min: 0, max: 120 }),
    body("heightCm").optional().isFloat({ min: 0 }),
    body("weightKg").optional().isFloat({ min: 0 }),
    body("activityLevel")
      .optional()
      .isIn(["sedentary", "light", "moderate", "active", "very_active"]),
    body("goal")
      .optional()
      .isIn(["lose_weight", "maintain_weight", "gain_weight", "gain_muscle"]),
  ],
  validateRequest,
  updateUserProfile
);

module.exports = router;
